package org.openmux.bridge

import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Api(
    private val cfg: BridgeConfig,
    private val engine: FfmpegEngine,
    private val manager: SessionManager,
    private val versionName: String,
    private val portProvider: () -> Int
) {
    private val startedAt = System.currentTimeMillis()
    private val fileRe = Regex("^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
    private val idRe = Regex("^[0-9a-f]{32}$")

    fun handle(req: HttpReq, resp: Resp) {
        val port = portProvider()
        val host = req.headers["host"]?.lowercase()
        if (host != "127.0.0.1:$port" && host != "localhost:$port" && host != "[::1]:$port") {
            resp.error(403, "Host não permitido"); return
        }
        if (req.headers.containsKey("origin") && !cfg.allowBrowserOrigins) {
            resp.error(403, "requisições de navegador (Origin) não são aceitas"); return
        }
        if (req.method == "OPTIONS") {
            resp.head(204, emptyMap(), 0); return
        }
        val p = req.path
        when {
            p == "/health" -> health(req, resp)
            p.startsWith("/_src/") -> source(req, resp)
            p.startsWith("/stream/") -> stream(req, resp)
            else -> {
                if (cfg.requireToken) {
                    val t = req.headers["x-openmux-token"]
                    if (t == null || !Ids.constantTimeEquals(t, cfg.token)) {
                        resp.error(401, "token ausente ou inválido (X-OpenMux-Token)"); return
                    }
                }
                api(req, resp)
            }
        }
    }

    // ------------------------------------------------------------------ /health

    private fun health(req: HttpReq, resp: Resp) {
        if (req.method != "GET" && req.method != "HEAD") {
            resp.error(405, "método não permitido"); return
        }
        resp.json(200, JSONObject().put("status", "ok").put("app", "OpenMux Bridge").put("version", versionName))
    }

    // ------------------------------------------------------------------ API de controle

    private fun statusJson(withDiag: Boolean): JSONObject {
        val o = JSONObject()
        o.put("status", "ok")
        o.put("version", versionName)
        o.put("uptimeSec", (System.currentTimeMillis() - startedAt) / 1000)
        o.put("port", portProvider())
        o.put("tokenRequired", cfg.requireToken)
        o.put("maxSessions", cfg.maxSessions)
        o.put("activeSessions", manager.activeCount())
        val e = JSONObject()
        e.put("available", engine.available())
        e.put("version", engine.version())
        e.put("deviceAbis", engine.abis())
        o.put("engine", e)
        val arr = JSONArray()
        for (s in manager.all()) arr.put(s.toJson(manager.streamUrl(s)))
        o.put("sessions", arr)
        if (withDiag) {
            val rt = Runtime.getRuntime()
            val d = JSONObject()
            d.put("android", Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")")
            d.put("device", Build.MANUFACTURER + " " + Build.MODEL)
            d.put("jvmUsedMb", (rt.totalMemory() - rt.freeMemory()) / 1048576)
            d.put("jvmMaxMb", rt.maxMemory() / 1048576)
            d.put("allowPrivateHosts", cfg.allowPrivateHosts)
            d.put("log", JSONArray(Diag.tail(80)))
            o.put("diag", d)
        }
        return o
    }

    private fun api(req: HttpReq, resp: Resp) {
        val p = req.path.trimEnd('/')
        val m = req.method
        when {
            p == "/status" && m == "GET" -> resp.json(200, statusJson(false))
            p == "/diag" && m == "GET" -> resp.json(200, statusJson(true))

            p == "/mux" && m == "POST" -> {
                val o = try {
                    JSONObject(String(req.body, Charsets.UTF_8))
                } catch (e: Exception) {
                    throw RequestError(400, "JSON inválido")
                }
                val r = MuxRequestParser.parse(o)
                when (val res = manager.create(r)) {
                    is CreateResult.Direct -> {
                        val h = JSONObject()
                        for ((k, v) in res.request.video.headers) h.put(k, v)
                        resp.json(
                            200,
                            JSONObject().put("mode", "DIRECT").put("url", res.request.video.url)
                                .put("headers", h).put("session", JSONObject.NULL)
                        )
                    }
                    is CreateResult.Created -> {
                        val j = res.session.toJson(manager.streamUrl(res.session))
                        j.put("reused", res.reused)
                        resp.json(if (res.reused) 200 else 201, j)
                    }
                }
            }

            p.startsWith("/session/") -> {
                val rest = p.removePrefix("/session/").split('/')
                val id = rest[0]
                if (!idRe.matches(id)) throw RequestError(404, "sessão não encontrada")
                val s = manager.get(id) ?: throw RequestError(404, "sessão não encontrada")
                when {
                    rest.size == 1 && m == "GET" -> resp.json(200, s.toJson(manager.streamUrl(s)))
                    rest.size == 1 && m == "DELETE" -> {
                        manager.stop(id)
                        resp.json(200, JSONObject().put("stopped", true).put("id", id))
                    }
                    rest.size == 2 && rest[1] == "offset" && m == "POST" -> {
                        val o = try {
                            JSONObject(String(req.body, Charsets.UTF_8))
                        } catch (e: Exception) {
                            throw RequestError(400, "JSON inválido")
                        }
                        if (!o.has("offsetMs")) throw RequestError(400, "offsetMs é obrigatório")
                        val ns = manager.setOffset(id, o.optLong("offsetMs", 0L))
                        val j = ns.toJson(manager.streamUrl(ns))
                        j.put("note", "sessão reiniciada; recarregue o manifesto no player")
                        resp.json(200, j)
                    }
                    else -> resp.error(405, "método não permitido")
                }
            }
            else -> resp.error(404, "rota desconhecida")
        }
    }

    // ------------------------------------------------------------------ /_src/<sessão>/{v|a}

    private fun source(req: HttpReq, resp: Resp) {
        if (req.method != "GET" && req.method != "HEAD") {
            resp.error(405, "método não permitido"); return
        }
        val parts = req.path.removePrefix("/_src/").split('/')
        if (parts.size != 2 || !idRe.matches(parts[0])) {
            resp.error(404, "não encontrado"); return
        }
        val s = manager.get(parts[0])
        if (s == null || !s.isActive()) {
            resp.error(404, "sessão não encontrada"); return
        }
        val spec: SourceSpec?
        val counter: java.util.concurrent.atomic.AtomicLong
        when (parts[1]) {
            "v" -> { spec = s.request.video; counter = s.bytesVideo }
            "a" -> { spec = s.request.audio; counter = s.bytesAudio }
            else -> { resp.error(404, "não encontrado"); return }
        }
        if (spec == null) {
            resp.error(404, "fonte inexistente"); return
        }
        SourceFetcher.fetch(spec, req.method, req.headers["range"], cfg.allowPrivateHosts, resp, counter)
    }

    // ------------------------------------------------------------------ /stream/<sessão>/<arquivo>

    private fun stream(req: HttpReq, resp: Resp) {
        if (req.method != "GET" && req.method != "HEAD") {
            resp.error(405, "método não permitido"); return
        }
        val parts = req.path.removePrefix("/stream/").split('/')
        if (parts.size != 2 || !idRe.matches(parts[0]) || !fileRe.matches(parts[1])) {
            resp.error(404, "não encontrado"); return
        }
        val s = manager.get(parts[0])
        if (s == null || s.state == SessionState.STOPPED) {
            resp.error(404, "sessão não encontrada"); return
        }
        s.touch()
        val name = parts[1]

        if (name == "master.m3u8") {
            waitReady(s, 45_000)
            when (s.state) {
                SessionState.READY, SessionState.ENDED -> {
                    val f = File(s.dir, "master.m3u8")
                    if (!f.exists()) { resp.error(503, "manifesto ainda não disponível"); return }
                    resp.bytes(200, "application/vnd.apple.mpegurl", f.readBytes())
                }
                SessionState.FAILED -> resp.error(502, s.error ?: "sessão falhou")
                else -> resp.error(504, "sessão ainda preparando (tente novamente)")
            }
            return
        }
        if (s.state == SessionState.FAILED) {
            resp.error(502, s.error ?: "sessão falhou"); return
        }
        val f = File(s.dir, name)
        when {
            name == "index.m3u8" -> {
                if (!f.exists()) { resp.error(404, "não encontrado"); return }
                val text = HlsUtil.injectStart(f.readText())
                resp.bytes(200, "application/vnd.apple.mpegurl", text.toByteArray(Charsets.UTF_8))
            }
            name == "init.mp4" -> serve(f, req, resp, "video/mp4")
            else -> {
                val idx = HlsUtil.segmentIndex(name)
                if (idx == null) { resp.error(404, "não encontrado"); return }
                // Atualiza a janela de leitura ANTES de esperar: isso destrava o ffmpeg pausado.
                var cur = s.maxRequestedSeg.get()
                while (idx > cur && !s.maxRequestedSeg.compareAndSet(cur, idx)) cur = s.maxRequestedSeg.get()
                val deadline = System.currentTimeMillis() + 30_000
                while (!f.exists() && s.isActive() && s.state != SessionState.ENDED && System.currentTimeMillis() < deadline) {
                    Thread.sleep(150)
                }
                val ct = if (name.endsWith(".ts")) "video/mp2t" else "video/mp4"
                serve(f, req, resp, ct)
            }
        }
    }

    private fun serve(f: File, req: HttpReq, resp: Resp, ct: String) {
        if (!f.exists()) {
            resp.error(404, "segmento indisponível (fora da janela mantida ou não gerado)"); return
        }
        resp.file(f, req.headers["range"], ct)
    }

    private fun waitReady(s: Session, timeoutMs: Long) {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (s.state == SessionState.READY || s.state == SessionState.ENDED ||
                s.state == SessionState.FAILED || s.state == SessionState.STOPPED
            ) return
            Thread.sleep(200)
        }
    }
}
