package org.openmux.bridge

import android.content.Context
import android.os.Build
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * FFmpeg/FFprobe são executáveis ARM empacotados como libffmpeg.so / libffprobe.so em
 * jniLibs/<abi>/. Com extractNativeLibs=true o PackageManager os extrai para nativeLibraryDir,
 * o único local executável para apps no Android 10+ (W^X). Rodam como processos filhos:
 * um crash do ffmpeg não derruba o serviço.
 */
class FfmpegEngine(ctx: Context) {
    private val dir = ctx.applicationInfo.nativeLibraryDir
    val ffmpeg = File(dir, "libffmpeg.so")
    val ffprobe = File(dir, "libffprobe.so")

    @Volatile
    private var versionCache: String? = null

    fun available(): Boolean = ffmpeg.exists() && ffprobe.exists() && ffmpeg.canExecute() && ffprobe.canExecute()

    fun abis(): String = Build.SUPPORTED_ABIS.joinToString(",")

    fun version(): String {
        versionCache?.let { return it }
        if (!available()) return "ausente"
        val r = try {
            runCapture(ffmpeg, listOf("-hide_banner", "-version"), 10_000)
        } catch (e: Exception) {
            null
        }
        val v = r?.second?.lineSequence()?.firstOrNull { it.isNotBlank() } ?: "falhou ao executar"
        if (r != null && r.first == 0) versionCache = v
        return v
    }

    /** Retorna (código de saída, stdout, stderr). Lança em timeout. */
    fun runCapture(bin: File, args: List<String>, timeoutMs: Long): Triple<Int, String, String> {
        val pb = ProcessBuilder(listOf(bin.path) + args)
        val p = pb.start()
        p.outputStream.close()
        val out = StringBuilder()
        val err = StringBuilder()
        val t1 = thread(isDaemon = true) { try { out.append(p.inputStream.bufferedReader().readText()) } catch (_: Exception) {} }
        val t2 = thread(isDaemon = true) { try { err.append(p.errorStream.bufferedReader().readText()) } catch (_: Exception) {} }
        val end = System.currentTimeMillis() + timeoutMs
        var code: Int? = null
        while (System.currentTimeMillis() < end) {
            code = Procs.exitCode(p)
            if (code != null) break
            Thread.sleep(50)
        }
        if (code == null) {
            Procs.kill(p)
            throw java.io.IOException("timeout executando ${bin.name}")
        }
        t1.join(2000)
        t2.join(2000)
        return Triple(code, out.toString(), err.toString())
    }

    fun probe(url: String, timeoutMs: Long = 45_000): ProbeResult {
        val r = runCapture(ffprobe, CommandBuilder.probeArgs(url), timeoutMs)
        if (r.first != 0) {
            throw java.io.IOException("ffprobe falhou (${r.first}): " + Redact.text(r.third.trim().takeLast(300)))
        }
        return ProbeParser.parse(r.second)
    }

    fun unitSeconds(ms: Long) = TimeUnit.MILLISECONDS.toSeconds(ms)
}

object Procs {
    fun pid(p: Process): Int {
        try {
            if (Build.VERSION.SDK_INT >= 33) return p.pid().toInt()
        } catch (_: Throwable) {
        }
        return try {
            val f = p.javaClass.getDeclaredField("pid")
            f.isAccessible = true
            f.getInt(p)
        } catch (_: Throwable) {
            -1
        }
    }

    fun signal(p: Process, sig: Int): Boolean {
        val id = pid(p)
        if (id <= 0) return false
        return try {
            android.os.Process.sendSignal(id, sig)
            true
        } catch (_: Throwable) {
            false
        }
    }

    /** SIGCONT antes de SIGKILL: um processo parado (SIGSTOP) não processa SIGTERM. */
    fun kill(p: Process) {
        signal(p, 18)
        if (!signal(p, 9)) p.destroy()
    }

    fun exitCode(p: Process): Int? = try {
        p.exitValue()
    } catch (e: IllegalThreadStateException) {
        null
    }
}
