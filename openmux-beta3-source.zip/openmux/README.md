# OpenMux Bridge — Beta 2 (código-fonte)

App Android (Kotlin, sem dependências) que roda um servidor HTTP em 127.0.0.1:8765 e combina vídeo de uma
fonte com áudio de outra, via FFmpeg (stream copy) → HLS. Alvo: TCL C6K (armeabi-v7a).

## STATUS HONESTO
| Item | Estado |
|---|---|
| Código Kotlin (serviço, API, sessões, proxy de fonte, HLS, UI) | Implementado, **NÃO compilado** (sem SDK/NDK no ambiente) |
| Testes unitários (`CoreLogicTest.kt`) | Escritos, **NÃO executados** |
| Argumentos de mux/HLS/sync | **Testados no host** com ffmpeg x86: `scripts/test-mux-host.sh` (25/25 OK) |
| FFmpeg ARMv7a (`scripts/build-ffmpeg.sh`) | Escrito, **NÃO executado** |
| APK `OpenMuxBridge-Beta2-armv7a.apk` | **NÃO existe ainda.** Será gerado pelo GitHub Actions |
| Teste no aparelho (`scripts/device-smoke-test.sh`) | **NÃO executado** |
| Plugin Nuvio acessar localhost | **Desconhecido**; teste com `plugin-probe/openmux-probe.js` |
| Seek livre no filme todo | Pendente |

## Como gerar o APK (sem Android Studio)
1. Crie um repositório no GitHub e suba esta pasta (pode ser pelo site: "Add file > Upload files").
2. Aba **Actions** > "Build OpenMux Bridge" > **Run workflow**.
3. Ao terminar, baixe o artefato `OpenMuxBridge-Beta2-armv7a` (APK + sha256).
   Se falhar, copie o log do passo que falhou: é esperado haver ajustes na primeira execução.

## Instalar na TV
Instale via adb ou "Downloader"/pendrive, abra o app **uma vez** (necessário para o início automático no boot).

## API
- `GET /health`, `GET /status`, `GET /diag`
- `POST /mux` `{videoUrl, videoHeaders, audioUrl, audioHeaders, audioLanguage, contentId, durationSec, offsetMs, output:{segmentType,segmentSeconds,allowAudioReencode}, mode:auto|mux|direct}`
  - DIRECT (sem áudio ou mesma URL): devolve a URL original, sem ffmpeg.
  - MUX: devolve `streamUrl` (`/stream/{id}/master.m3u8`).
- `GET|DELETE /session/{id}`, `POST /session/{id}/offset {offsetMs}`

## Segurança
Só 127.0.0.1; rejeita Host/Origin estranhos; fontes privadas/loopback bloqueadas por padrão; não é proxy aberto
(`/_src/` só serve fontes da sessão); logs sem URLs completas/tokens; token opcional (`requireToken`).

## Limitações conhecidas
Cópia de streams não corrige diferença de velocidade (25 vs 23,976 fps) nem cortes diferentes: use `offsetMs`
ou `allowAudioReencode` (reencoda só o áudio). Android exige notificação mínima de serviço em primeiro plano.
Licenças: ver `LICENSE` e `THIRD_PARTY_NOTICES.md` (FFmpeg LGPL).
