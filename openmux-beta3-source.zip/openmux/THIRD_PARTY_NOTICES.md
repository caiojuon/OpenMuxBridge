# Avisos de terceiros

## FFmpeg (libffmpeg.so / libffprobe.so)
- Projeto: https://github.com/FFmpeg/FFmpeg (tag configurável em `scripts/build-ffmpeg.sh`, padrão `n7.1.1`).
- Licença efetiva: **LGPL v2.1 ou posterior**. O script de build NÃO usa `--enable-gpl` nem
  `--enable-nonfree` e não liga bibliotecas externas (sem x264/x265/fdk-aac/OpenSSL).
- Os binários são executáveis estáticos separados do código do app (processos filhos), compilados
  por `scripts/build-ffmpeg.sh`; o código-fonte exato é o da tag acima do repositório oficial, e a
  configuração usada é gravada em `FFMPEG_BUILD_INFO.txt` junto do APK. Quem redistribuir o APK deve
  manter este aviso e disponibilizar o script e a tag usados.
- Marca "FFmpeg" pertence aos respectivos titulares; este projeto não é afiliado a eles.

## Código do app
- Kotlin/Android sem bibliotecas de terceiros em tempo de execução (apenas o framework Android).
- Testes: JUnit 4 (EPL-1.0) e org.json (licença JSON) — somente em build/teste, não vão no APK.
