plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "org.openmux.bridge"
    compileSdk = 34

    defaultConfig {
        applicationId = "org.openmux.bridge"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "0.3.0-beta3"

        // Prioridade absoluta: armeabi-v7a (TCL C6K, userspace 32 bits).
        // Para habilitar 64 bits depois: acrescente "arm64-v8a" aqui e rode
        // scripts/build-ffmpeg.sh arm64-v8a (gera jniLibs/arm64-v8a/).
        ndk {
            abiFilters += listOf("armeabi-v7a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Beta: assinado com a chave debug gerada pelo AGP (sideload apenas).
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        jniLibs {
            // OBRIGATÓRIO: o ffmpeg/ffprobe são executáveis empacotados como lib*.so.
            // Eles precisam ser extraídos para nativeLibraryDir (único lugar executável
            // no Android 10+ para apps comuns).
            useLegacyPackaging = true
            // Não deixar o AGP "strip" mexer nos executáveis.
            keepDebugSymbols += listOf("**/libffmpeg.so", "**/libffprobe.so")
        }
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
    // org.json real para testes JVM (no aparelho vem do framework Android).
    testImplementation("org.json:json:20240303")
}
