package org.openmux.bridge

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.net.InetAddress

class UrlValidatorTest {
    private val publicIp = { _: String -> listOf(InetAddress.getByName("93.184.216.34")) }
    private fun resolveTo(ip: String) = { _: String -> listOf(InetAddress.getByName(ip)) }

    @Test fun acceptsHttps() {
        val u = UrlValidator.validate("https://cdn.example.com/a/b.mkv?x=1", false, publicIp)
        assertEquals("cdn.example.com", u.host)
    }

    @Test fun rejectsOtherSchemes() {
        for (s in listOf("file:///etc/passwd", "ftp://a/b", "javascript:alert(1)")) {
            try { UrlValidator.validate(s, false, publicIp); fail(s) } catch (_: RejectedException) {}
        }
    }

    @Test fun rejectsPrivateTargets() {
        for (ip in listOf("127.0.0.1", "10.0.0.5", "192.168.1.10", "172.16.4.4", "169.254.169.254", "100.64.0.1", "0.0.0.0", "::1")) {
            try { UrlValidator.validate("http://x.example/v.mkv", false, resolveTo(ip)); fail(ip) } catch (_: RejectedException) {}
        }
    }

    @Test fun allowsPrivateWhenEnabled() {
        UrlValidator.validate("http://192.168.1.10/v.mkv", true, resolveTo("192.168.1.10"))
    }

    @Test fun rejectsEmbeddedCredentials() {
        try { UrlValidator.validate("https://user:pw@a.example/x", false, publicIp); fail() } catch (_: RejectedException) {}
    }

    @Test fun headerSanitizing() {
        val h = UrlValidator.sanitizeHeaders(mapOf("Referer" to "https://a/", "Host" to "evil", "Range" to "bytes=0-1", "Cookie" to "a=b"))
        assertEquals(setOf("Referer", "Cookie"), h.keys)
        try { UrlValidator.sanitizeHeaders(mapOf("X-A" to "a\r\nInjected: 1")); fail() } catch (_: RejectedException) {}
        try { UrlValidator.sanitizeHeaders(mapOf("Bad Name" to "a")); fail() } catch (_: RejectedException) {}
    }
}

class RedactTest {
    @Test fun urlsLoseTheirPathAndQuery() {
        val r = Redact.text("opening https://host.example:8443/secret/tokenabc/file.mkv?sig=zzz failed")
        assertFalse(r.contains("tokenabc"))
        assertFalse(r.contains("zzz"))
        assertTrue(r.contains("host.example"))
    }

    @Test fun secretsAreMasked() {
        val r = Redact.text("Authorization: Bearer abc123 cookie=sessionid42")
        assertFalse(r.contains("abc123"))
        assertFalse(r.contains("sessionid42"))
    }
}

class CommandBuilderTest {
    private fun plan(off: Double = 0.0, tempo: Double? = null, type: String = "fmp4") = MuxPlan(
        "http://127.0.0.1:8765/_src/x/v", "http://127.0.0.1:8765/_src/x/a", 0, 1, off, tempo, "pt-BR", type, 4, "/tmp/o"
    )

    @Test fun copyModeHasNoReencode() {
        val a = CommandBuilder.muxArgs(plan())
        assertTrue(a.containsAll(listOf("-c:v", "copy", "-c:a", "copy")))
        assertFalse(a.contains("-itsoffset"))
        assertFalse(a.contains("-filter:a"))
        assertTrue(a.contains("0:v:0"))
        assertTrue(a.contains("1:a:1"))
    }

    @Test fun offsetGoesBeforeAudioInput() {
        val a = CommandBuilder.muxArgs(plan(off = -0.5))
        val io = a.indexOf("-itsoffset")
        assertTrue(io > 0)
        assertEquals("-0.500", a[io + 1])
        assertEquals("-i", a[io + 2])
        assertTrue(a[io + 3].endsWith("/a"))
    }

    @Test fun tempoReencodesOnlyAudio() {
        val a = CommandBuilder.muxArgs(plan(tempo = 0.959))
        assertTrue(a.contains("-filter:a"))
        assertTrue(a.contains("aac"))
        assertEquals("copy", a[a.indexOf("-c:v") + 1])
    }

    @Test fun segmentTypes() {
        assertTrue(CommandBuilder.muxArgs(plan(type = "fmp4")).contains("init.mp4"))
        val ts = CommandBuilder.muxArgs(plan(type = "mpegts"))
        assertFalse(ts.contains("init.mp4"))
        assertTrue(ts.last() == "/tmp/o/index.m3u8")
    }

    @Test fun languageNormalization() {
        assertEquals("por", CommandBuilder.lang3("pt-BR"))
        assertEquals("por", CommandBuilder.lang3("pob"))
        assertEquals("eng", CommandBuilder.lang3("en"))
        assertNull(CommandBuilder.lang3("x"))
        assertTrue(CommandBuilder.langMatches("por", "pt-BR"))
        assertFalse(CommandBuilder.langMatches("eng", "pt-BR"))
    }

    @Test fun credentialsNeverInArgs() {
        val joined = CommandBuilder.muxArgs(plan()).joinToString(" ")
        assertFalse(joined.contains("Authorization"))
        assertFalse(joined.contains("Cookie"))
    }
}

class ProbeAndSyncTest {
    private val sample = """
    {"streams":[
      {"index":0,"codec_name":"h264","codec_type":"video","width":3840,"height":2160,"start_time":"0.000000","bit_rate":"30000000","disposition":{"attached_pic":0}},
      {"index":1,"codec_name":"eac3","codec_type":"audio","channels":6,"start_time":"0.000000","tags":{"language":"eng"},"disposition":{"attached_pic":0}},
      {"index":2,"codec_name":"ac3","codec_type":"audio","channels":6,"start_time":"0.000000","tags":{"language":"por"},"disposition":{"attached_pic":0}},
      {"index":3,"codec_name":"mjpeg","codec_type":"video","start_time":"N/A","disposition":{"attached_pic":1}}
    ],
    "format":{"format_name":"matroska,webm","start_time":"0.000000","duration":"7200.5","bit_rate":"31000000"}}
    """

    @Test fun parsesStreamsAndTypeIndices() {
        val p = ProbeParser.parse(sample)
        assertEquals(4, p.streams.size)
        assertEquals(7200.5, p.durationSec!!, 0.001)
        val audios = p.streams.filter { it.type == "audio" }
        assertEquals(listOf(0, 1), audios.map { it.typeIndex })
        assertEquals("por", audios[1].lang)
        val pic = p.streams.first { it.index == 3 }
        assertTrue(pic.attachedPic)
        assertEquals(1, pic.typeIndex)
        assertNull(pic.startSec)
    }

    private fun probe(dur: Double) = ProbeResult("matroska", 0.0, dur, null, emptyList())
    private val vs = StreamInfo(0, "video", 0, "h264", null, null, 1920, 1080, 0.0, null, false)
    private val au = StreamInfo(1, "audio", 0, "ac3", "por", 6, null, null, 0.0, null, false)

    @Test fun identicalDurationsNoWarning() {
        val s = SyncPlanner.plan(probe(7200.0), vs, probe(7200.4), au, 0, null, false)
        assertTrue(s.warnings.isEmpty())
        assertNull(s.audioTempo)
        assertEquals(0.0, s.audioOffsetSec, 0.0)
    }

    @Test fun palSpeedupDetected() {
        // 25 fps vs 23.976 fps: áudio ~4.27% mais curto
        val v = probe(7200.0)
        val a = probe(7200.0 / 1.0427)
        val noRe = SyncPlanner.plan(v, vs, a, au, 0, null, false)
        assertNull(noRe.audioTempo)
        assertTrue(noRe.warnings.isNotEmpty())
        val re = SyncPlanner.plan(v, vs, a, au, 0, null, true)
        assertNotNull(re.audioTempo)
        // atempo < 1 desacelera o áudio até casar com a duração do vídeo
        assertEquals(1.0 / 1.0427, re.audioTempo!!, 0.0005)
    }

    @Test fun userOffsetPassedThrough() {
        val s = SyncPlanner.plan(probe(100.0), vs, probe(100.0), au, 750, null, false)
        assertEquals(0.75, s.audioOffsetSec, 1e-9)
    }

    @Test fun hlsStartTagInjected() {
        val pl = "#EXTM3U\n#EXT-X-VERSION:7\n#EXT-X-TARGETDURATION:4\n#EXTINF:4.0,\nseg00000.m4s\n"
        val out = HlsUtil.injectStart(pl)
        assertTrue(out.lines()[2].startsWith("#EXT-X-START"))
        assertEquals(out, HlsUtil.injectStart(out)) // idempotente
        assertEquals(12, HlsUtil.segmentIndex("seg00012.m4s"))
        assertNull(HlsUtil.segmentIndex("../seg00012.m4s"))
    }
}

class RequestParserTest {
    @Test fun flatAndNestedForms() {
        val flat = MuxRequestParser.parse(JSONObject("""{"videoUrl":"https://a/v.mkv","audioUrl":"https://b/a.mkv","videoHeaders":{"Referer":"https://a"},"audioLanguage":"pt-BR","offsetMs":-250}"""))
        assertEquals("https://a", flat.video.headers["Referer"])
        assertEquals(-250L, flat.offsetMs)
        val nested = MuxRequestParser.parse(JSONObject("""{"video":{"url":"https://a/v.mkv","headers":{"X":"1"}},"audio":{"url":"https://b/a.mkv"},"mode":"mux"}"""))
        assertEquals("1", nested.video.headers["X"])
        assertEquals("mux", nested.mode)
    }

    @Test fun validation() {
        try { MuxRequestParser.parse(JSONObject("""{"audioUrl":"https://b/a"}""")); fail() } catch (e: RequestError) { assertEquals(400, e.code) }
        try { MuxRequestParser.parse(JSONObject("""{"videoUrl":"https://a/v","mode":"mux"}""")); fail() } catch (e: RequestError) { assertEquals(400, e.code) }
        try { MuxRequestParser.parse(JSONObject("""{"videoUrl":"https://a/v","offsetMs":99999999}""")); fail() } catch (e: RequestError) { assertEquals(400, e.code) }
    }
}
