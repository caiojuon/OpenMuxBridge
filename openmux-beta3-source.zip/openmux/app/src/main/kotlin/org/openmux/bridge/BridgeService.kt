package org.openmux.bridge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

class BridgeRuntime(
    val cfg: BridgeConfig,
    val engine: FfmpegEngine,
    val manager: SessionManager,
    val server: LocalHttpServer,
    val versionName: String
)

class BridgeService : Service() {
    companion object {
        const val ACTION_STOP = "org.openmux.bridge.STOP"
        private const val CHANNEL = "openmux_bridge"
        private const val NOTIF_ID = 8765

        @Volatile var runtime: BridgeRuntime? = null
        @Volatile var userStopped = false

        fun start(ctx: Context) {
            try {
                val i = Intent(ctx, BridgeService::class.java)
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (e: Exception) {
                // Android 12+ pode recusar início em segundo plano fora das exceções (ex.: BOOT_COMPLETED).
                Diag.log("service", "não foi possível iniciar: ${e.javaClass.simpleName}")
            }
        }

        fun stop(ctx: Context) {
            userStopped = true
            ctx.stopService(Intent(ctx, BridgeService::class.java))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startInForeground()
        bringUp()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            userStopped = true
            stopSelf()
            return START_NOT_STICKY
        }
        userStopped = false
        if (runtime == null) bringUp()
        return START_STICKY // o sistema recria o serviço se ele for morto
    }

    override fun onDestroy() {
        runtime?.let {
            try { it.server.stop() } catch (_: Exception) {}
            try { it.manager.stopAll() } catch (_: Exception) {}
        }
        runtime = null
        Diag.log("service", "parado")
        super.onDestroy()
    }

    private fun bringUp() {
        if (runtime != null) return
        try {
            val cfg = BridgeConfig.from(this)
            val engine = FfmpegEngine(this)
            val manager = SessionManager(this, cfg, engine) { cfg.port }
            val version = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "?" } catch (e: Exception) { "?" }
            val api = Api(cfg, engine, manager, version) { cfg.port }
            val server = LocalHttpServer(cfg.port) { req, resp -> api.handle(req, resp) }
            server.start()
            runtime = BridgeRuntime(cfg, engine, manager, server, version)
            Diag.log("service", "ativo em 127.0.0.1:${cfg.port}; motor=${if (engine.available()) "ok" else "AUSENTE"}")
        } catch (e: Exception) {
            Diag.log("service", "falha ao subir: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun startInForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            // IMPORTANCE_MIN: a notificação mais discreta que o Android permite para um serviço em primeiro plano.
            val ch = NotificationChannel(CHANNEL, "OpenMux Bridge", NotificationManager.IMPORTANCE_MIN)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        b.setContentTitle("OpenMux Bridge ativo")
            .setContentText("Serviço local de multiplexação")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentIntent(open)
            .setOngoing(true)
        val n = b.build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }
}
