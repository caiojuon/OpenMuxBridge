package org.openmux.bridge

import java.net.Inet6Address
import java.net.InetAddress
import java.net.URL

class RejectedException(message: String) : Exception(message)

object UrlValidator {
    private val BLOCKED_HEADERS = setOf(
        "host", "content-length", "connection", "transfer-encoding", "upgrade", "range",
        "te", "expect", "keep-alive", "accept-encoding", "proxy-connection", "if-range"
    )
    private val NAME_RE = Regex("^[!#\$%&'*+\\-.^_`|~0-9A-Za-z]+\$")

    /**
     * Valida uma URL de fonte. Só http/https, sem credenciais embutidas, e (por padrão)
     * sem destinos privados/loopback/link-local, para o Bridge não virar ponte para a LAN.
     */
    fun validate(
        raw: String,
        allowPrivate: Boolean,
        resolver: (String) -> List<InetAddress> = { h -> InetAddress.getAllByName(h).toList() }
    ): URL {
        if (raw.length > 8192) throw RejectedException("URL too long")
        val url = try {
            URL(raw.trim())
        } catch (e: Exception) {
            throw RejectedException("invalid URL")
        }
        val proto = url.protocol.lowercase()
        if (proto != "http" && proto != "https") throw RejectedException("only http/https allowed")
        val host = url.host
        if (host.isNullOrEmpty()) throw RejectedException("missing host")
        if (url.userInfo != null) throw RejectedException("credentials in URL not allowed; send them as headers")
        if (!allowPrivate) {
            val addrs = try {
                resolver(host)
            } catch (e: Exception) {
                throw RejectedException("cannot resolve host")
            }
            if (addrs.isEmpty() || addrs.any { isPrivate(it) }) {
                throw RejectedException("host not allowed (private/loopback address)")
            }
        }
        return url
    }

    fun isPrivate(a: InetAddress): Boolean {
        if (a.isAnyLocalAddress || a.isLoopbackAddress || a.isLinkLocalAddress ||
            a.isSiteLocalAddress || a.isMulticastAddress
        ) return true
        val b = a.address
        if (a is Inet6Address) {
            if ((b[0].toInt() and 0xFE) == 0xFC) return true // fc00::/7 (ULA)
        } else {
            val b0 = b[0].toInt() and 0xFF
            val b1 = b[1].toInt() and 0xFF
            if (b0 == 0) return true
            if (b0 == 100 && b1 in 64..127) return true // CGNAT 100.64/10
            if (b0 >= 240) return true
        }
        return false
    }

    /** Remove cabeçalhos que o Bridge controla e rejeita valores com CR/LF/NUL. */
    fun sanitizeHeaders(src: Map<String, String>): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        var total = 0
        for ((k, v) in src) {
            if (!NAME_RE.matches(k)) throw RejectedException("invalid header name")
            if (v.length > 4096 || v.any { it == '\r' || it == '\n' || it == '\u0000' }) {
                throw RejectedException("invalid header value")
            }
            if (k.lowercase() in BLOCKED_HEADERS) continue
            total += k.length + v.length
            if (total > 16384) throw RejectedException("headers too large")
            out[k] = v
        }
        return out
    }
}
