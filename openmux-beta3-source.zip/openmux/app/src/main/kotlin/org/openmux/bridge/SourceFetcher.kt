package org.openmux.bridge

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicLong

/**
 * Proxy de fonte por sessão. O ffmpeg só enxerga http://127.0.0.1:PORT/_src/<sessão>/{v|a};
 * quem fala com o provedor (TLS do Android, cabeçalhos, redirecionamentos) é este código.
 * Só atende fontes registradas na sessão: NÃO é proxy aberto.
 */
object SourceFetcher {
    private const val MAX_HOPS = 5
    private val SENSITIVE = setOf("authorization", "cookie", "proxy-authorization")
    private const val DEFAULT_UA = "Mozilla/5.0 (Linux; Android 11; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"

    fun fetch(
        spec: SourceSpec,
        method: String,
        rangeHeader: String?,
        allowPrivate: Boolean,
        resp: Resp,
        counter: AtomicLong
    ) {
        var url = URL(spec.url)
        val originHost = url.host
        val originProto = url.protocol
        var hops = 0
        var attempt = 0
        while (true) {
            try {
                UrlValidator.validate(url.toString(), allowPrivate)
            } catch (e: RejectedException) {
                resp.error(403, "destino não permitido: " + (e.message ?: ""))
                return
            }
            val conn = url.openConnection() as HttpURLConnection
            try {
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 15_000
                conn.readTimeout = 30_000
                conn.requestMethod = if (method == "HEAD") "HEAD" else "GET"
                val sameOrigin = url.host.equals(originHost, ignoreCase = true) && url.protocol == originProto
                var hasUa = false
                for ((k, v) in spec.headers) {
                    val lk = k.lowercase()
                    if (lk in SENSITIVE && !sameOrigin) continue // não vaza credenciais para outro host
                    if (lk == "user-agent") hasUa = true
                    conn.setRequestProperty(k, v)
                }
                if (!hasUa) conn.setRequestProperty("User-Agent", DEFAULT_UA)
                conn.setRequestProperty("Accept", "*/*")
                conn.setRequestProperty("Accept-Encoding", "identity")
                if (rangeHeader != null) conn.setRequestProperty("Range", rangeHeader)

                val code = conn.responseCode
                if (code in intArrayOf(301, 302, 303, 307, 308)) {
                    val loc = conn.getHeaderField("Location")
                    if (loc == null || ++hops > MAX_HOPS) {
                        resp.error(502, "redirecionamento inválido do provedor"); return
                    }
                    url = URL(url, loc)
                    continue
                }
                if (code >= 400) {
                    resp.error(if (code == 416) 416 else 502, "provedor respondeu HTTP $code")
                    return
                }
                val h = LinkedHashMap<String, String>()
                conn.getHeaderField("Content-Type")?.let { h["Content-Type"] = it }
                conn.getHeaderField("Content-Range")?.let { h["Content-Range"] = it }
                if (code == 206 || conn.getHeaderField("Accept-Ranges") != null) h["Accept-Ranges"] = "bytes"
                val len = conn.getHeaderField("Content-Length")?.toLongOrNull() ?: -1L
                resp.head(if (code == 206) 206 else 200, h, len)
                if (method == "HEAD") return
                val buf = ByteArray(65536)
                conn.inputStream.use { ins ->
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        resp.body(buf, 0, n)
                        counter.addAndGet(n.toLong())
                    }
                }
                return
            } catch (e: IOException) {
                // Falha de rede antes de enviar o cabeçalho: tenta de novo (até 3x). Depois do
                // cabeçalho, apenas encerra: o ffmpeg reconecta usando Range.
                if (resp.sent) throw e
                if (++attempt >= 3) {
                    resp.error(502, "falha ao falar com o provedor")
                    return
                }
                try { Thread.sleep(500L * attempt) } catch (_: InterruptedException) { return }
            } finally {
                conn.disconnect()
            }
        }
    }
}
