package org.openmux.bridge

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

enum class SessionState { CREATED, PROBING, STARTING, READY, ENDED, FAILED, STOPPED }

class Session(
    val id: String,
    val key: String,
    @Volatile var request: MuxRequest,
    val dir: File
) {
    val createdAt: Long = System.currentTimeMillis()
    val lastAccess = AtomicLong(createdAt)
    val maxRequestedSeg = AtomicInteger(-1)
    val bytesVideo = AtomicLong()
    val bytesAudio = AtomicLong()
    val warnings = CopyOnWriteArrayList<String>()
    private val logTail = java.util.ArrayDeque<String>()

    @Volatile var state = SessionState.CREATED
    @Volatile var error: String? = null
    @Volatile var endedAt = 0L
    @Volatile var process: Process? = null
    @Volatile var paused = false
    @Volatile var restartRequested = false
    @Volatile var segmentType = "fmp4"
    @Volatile var segmentsGenerated = 0
    @Volatile var audioTempo: Double? = null
    @Volatile var videoProbe: ProbeResult? = null
    @Volatile var audioProbe: ProbeResult? = null
    @Volatile var dirBytes = 0L

    fun touch() {
        lastAccess.set(System.currentTimeMillis())
    }

    fun isActive(): Boolean = state != SessionState.FAILED && state != SessionState.STOPPED

    @Synchronized
    fun addLog(line: String) {
        logTail.addLast(line)
        while (logTail.size > 40) logTail.removeFirst()
    }

    @Synchronized
    fun logLines(): List<String> = logTail.toList()

    fun toJson(streamUrl: String): JSONObject {
        val now = System.currentTimeMillis()
        val o = JSONObject()
        o.put("id", id)
        o.put("mode", "MUX")
        o.put("state", state.name)
        o.put("error", error ?: JSONObject.NULL)
        o.put("contentId", request.contentId ?: JSONObject.NULL)
        o.put("audioLanguage", request.audioLanguage ?: JSONObject.NULL)
        o.put("offsetMs", request.offsetMs)
        o.put("audioTempo", audioTempo ?: JSONObject.NULL)
        o.put("segmentType", segmentType)
        o.put("segmentsGenerated", segmentsGenerated)
        o.put("maxRequestedSegment", maxRequestedSeg.get())
        o.put("paused", paused)
        o.put("ageSec", (now - createdAt) / 1000)
        o.put("idleSec", (now - lastAccess.get()) / 1000)
        o.put("storageBytes", dirBytes)
        val b = JSONObject()
        b.put("video", bytesVideo.get())
        b.put("audio", bytesAudio.get())
        o.put("bytesFromSources", b)
        o.put("warnings", JSONArray(warnings.toList()))
        o.put("streamUrl", streamUrl)
        return o
    }
}
