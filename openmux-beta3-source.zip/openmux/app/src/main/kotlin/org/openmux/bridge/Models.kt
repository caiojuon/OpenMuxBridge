package org.openmux.bridge

import org.json.JSONObject

class RequestError(val code: Int, message: String) : Exception(message)

data class SourceSpec(val url: String, val headers: Map<String, String>)

data class OutputPrefs(
    val segmentType: String?,      // "fmp4" | "mpegts"
    val segmentSec: Int?,
    val allowAudioReencode: Boolean,
    val videoStream: Int?,         // índice 0:v:N
    val audioStream: Int?          // índice 1:a:N
)

data class MuxRequest(
    val video: SourceSpec,
    val audio: SourceSpec?,
    val audioLanguage: String?,
    val contentId: String?,
    val durationSec: Double?,
    val offsetMs: Long,
    val output: OutputPrefs,
    val clientSessionId: String?,
    val mode: String               // auto | mux | direct
)

object MuxRequestParser {
    private fun str(o: JSONObject, k: String): String? =
        if (o.isNull(k)) null else o.optString(k, "").ifEmpty { null }

    private fun headersOf(h: JSONObject?): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        if (h != null) {
            val it = h.keys()
            while (it.hasNext()) {
                val k = it.next()
                if (!h.isNull(k)) m[k] = h.optString(k, "")
            }
        }
        return m
    }

    /** Aceita {"videoUrl","videoHeaders"} ou {"video":{"url","headers"}} (idem áudio). */
    private fun source(o: JSONObject, urlKey: String, hdrKey: String, nestedKey: String): SourceSpec? {
        var url = str(o, urlKey)
        var hdrs = o.optJSONObject(hdrKey)
        val nested = o.optJSONObject(nestedKey)
        if (nested != null) {
            if (url == null) url = str(nested, "url")
            if (hdrs == null) hdrs = nested.optJSONObject("headers")
        }
        if (url == null) return null
        return SourceSpec(url, headersOf(hdrs))
    }

    fun parse(o: JSONObject): MuxRequest {
        val video = source(o, "videoUrl", "videoHeaders", "video")
            ?: throw RequestError(400, "videoUrl is required")
        val audio = source(o, "audioUrl", "audioHeaders", "audio")
        val mode = (str(o, "mode") ?: "auto").lowercase()
        if (mode != "auto" && mode != "mux" && mode != "direct") throw RequestError(400, "mode must be auto|mux|direct")
        if (mode == "mux" && audio == null) throw RequestError(400, "audioUrl is required for mode=mux")

        val offset = if (o.has("offsetMs") && !o.isNull("offsetMs")) o.optLong("offsetMs", 0L) else 0L
        if (offset < -600000L || offset > 600000L) throw RequestError(400, "offsetMs out of range (±600000)")

        val dur = if (o.has("durationSec") && !o.isNull("durationSec")) o.optDouble("durationSec", Double.NaN) else Double.NaN
        val out = o.optJSONObject("output")
        val prefs = OutputPrefs(
            segmentType = out?.let { str(it, "segmentType") }?.lowercase(),
            segmentSec = out?.let { if (it.has("segmentSeconds") && !it.isNull("segmentSeconds")) it.optInt("segmentSeconds") else null },
            allowAudioReencode = out?.optBoolean("allowAudioReencode", false) ?: false,
            videoStream = out?.let { if (it.has("videoStream") && !it.isNull("videoStream")) it.optInt("videoStream") else null },
            audioStream = out?.let { if (it.has("audioStream") && !it.isNull("audioStream")) it.optInt("audioStream") else null }
        )
        return MuxRequest(
            video = video,
            audio = audio,
            audioLanguage = str(o, "audioLanguage"),
            contentId = str(o, "contentId")?.take(200),
            durationSec = if (dur.isNaN() || dur <= 0) null else dur,
            offsetMs = offset,
            output = prefs,
            clientSessionId = str(o, "clientSessionId")?.take(100),
            mode = mode
        )
    }
}
