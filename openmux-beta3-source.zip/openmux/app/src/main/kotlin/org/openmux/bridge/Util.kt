package org.openmux.bridge

import java.security.MessageDigest
import java.security.SecureRandom

/** Remove URLs completas, tokens e cookies de qualquer texto que vá para log/diagnóstico. */
object Redact {
    private val URL_RE = Regex("""https?://[^\s'"<>]+""", RegexOption.IGNORE_CASE)
    private val HEADER_RE = Regex(
        """(?i)(proxy-authorization|authorization|set-cookie|cookie)(["']?\s*[:=]\s*)[^\r\n]+"""
    )
    private val SECRET_RE = Regex(
        """(?i)(token|api[_-]?key|password|passwd|secret|signature|sig)(["']?\s*[:=]\s*)[^\s&"',;]+"""
    )

    /** Mantém apenas esquema://host[:porta]/… (caminho e query podem conter tokens). */
    fun url(raw: String): String {
        return try {
            val u = java.net.URL(raw)
            val port = if (u.port > 0) ":" + u.port else ""
            u.protocol + "://" + u.host + port + "/…"
        } catch (e: Exception) {
            "<url>"
        }
    }

    fun text(s: String): String {
        var r = URL_RE.replace(s) { m -> url(m.value) }
        r = HEADER_RE.replace(r) { m -> m.groupValues[1] + m.groupValues[2] + "***" }
        r = SECRET_RE.replace(r) { m -> m.groupValues[1] + m.groupValues[2] + "***" }
        return r
    }
}

object Ids {
    private val rnd = SecureRandom()

    fun newId(): String {
        val b = ByteArray(16)
        rnd.nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    fun sha256Hex(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    fun constantTimeEquals(a: String, b: String): Boolean =
        MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))
}

/** Ring buffer de log técnico (sempre redigido) usado pela UI e por /diag. */
object Diag {
    private val lines = java.util.ArrayDeque<String>()
    private const val MAX = 300

    @Synchronized
    fun log(tag: String, msg: String) {
        val ts = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        val line = ts + " " + tag + ": " + Redact.text(msg)
        lines.addLast(line)
        while (lines.size > MAX) lines.removeFirst()
        try {
            android.util.Log.i("OpenMux", line)
        } catch (_: Throwable) {
        }
    }

    @Synchronized
    fun tail(n: Int): List<String> = lines.toList().takeLast(n)
}

object HlsUtil {
    /** ExoPlayer trata playlists EVENT sem ENDLIST como "ao vivo" e pularia para o fim. */
    fun injectStart(playlist: String): String {
        if (playlist.contains("#EXT-X-START")) return playlist
        val nl = playlist.split("\n").toMutableList()
        val idx = nl.indexOfFirst { it.startsWith("#EXT-X-VERSION") }
        val tag = "#EXT-X-START:TIME-OFFSET=0.0,PRECISE=YES"
        if (idx >= 0) nl.add(idx + 1, tag) else if (nl.isNotEmpty()) nl.add(1, tag)
        return nl.joinToString("\n")
    }

    private val SEG_RE = Regex("""^seg(\d+)\.(m4s|ts)$""")

    fun segmentIndex(name: String): Int? = SEG_RE.find(name)?.groupValues?.get(1)?.toIntOrNull()
}
