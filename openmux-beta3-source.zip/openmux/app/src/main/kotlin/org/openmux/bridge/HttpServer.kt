package org.openmux.bridge

import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.SynchronousQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class HttpReq(
    val method: String,
    val path: String,
    val query: String?,
    val headers: Map<String, String>,   // nomes em minúsculas
    val body: ByteArray
)

class Resp(private val out: OutputStream, private val isHead: Boolean) {
    var sent = false
        private set

    private fun reason(c: Int) = when (c) {
        200 -> "OK"; 201 -> "Created"; 202 -> "Accepted"; 204 -> "No Content"; 206 -> "Partial Content"
        400 -> "Bad Request"; 401 -> "Unauthorized"; 403 -> "Forbidden"; 404 -> "Not Found"
        405 -> "Method Not Allowed"; 409 -> "Conflict"; 413 -> "Payload Too Large"; 416 -> "Range Not Satisfiable"
        429 -> "Too Many Requests"; 500 -> "Internal Server Error"; 502 -> "Bad Gateway"
        503 -> "Service Unavailable"; 504 -> "Gateway Timeout"; else -> "Status"
    }

    private fun clean(v: String) = v.replace("\r", " ").replace("\n", " ")

    fun head(code: Int, headers: Map<String, String> = emptyMap(), length: Long = -1) {
        val sb = StringBuilder("HTTP/1.1 ").append(code).append(' ').append(reason(code)).append("\r\n")
        sb.append("Connection: close\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\n")
        if (length >= 0) sb.append("Content-Length: ").append(length).append("\r\n")
        for ((k, v) in headers) sb.append(clean(k)).append(": ").append(clean(v)).append("\r\n")
        sb.append("\r\n")
        out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
        sent = true
    }

    fun body(b: ByteArray, off: Int, len: Int) {
        if (!isHead) out.write(b, off, len)
    }

    fun bytes(code: Int, contentType: String, b: ByteArray) {
        head(code, mapOf("Content-Type" to contentType), b.size.toLong())
        body(b, 0, b.size)
    }

    fun json(code: Int, o: JSONObject) = bytes(code, "application/json; charset=utf-8", o.toString().toByteArray(Charsets.UTF_8))

    fun error(code: Int, msg: String) = json(code, JSONObject().put("error", msg).put("code", code))

    fun file(f: File, range: String?, contentType: String) {
        val size = f.length()
        var start = 0L
        var end = size - 1
        var code = 200
        if (range != null) {
            val m = Regex("^bytes=(\\d*)-(\\d*)$").find(range.trim())
            if (m != null && (m.groupValues[1].isNotEmpty() || m.groupValues[2].isNotEmpty())) {
                if (m.groupValues[1].isNotEmpty()) {
                    start = m.groupValues[1].toLong()
                    if (m.groupValues[2].isNotEmpty()) end = minOf(m.groupValues[2].toLong(), size - 1)
                } else {
                    start = maxOf(0L, size - m.groupValues[2].toLong())
                }
                if (start >= size || start > end) {
                    head(416, mapOf("Content-Range" to "bytes */$size"), 0)
                    return
                }
                code = 206
            }
        }
        val len = end - start + 1
        val h = LinkedHashMap<String, String>()
        h["Content-Type"] = contentType
        h["Accept-Ranges"] = "bytes"
        if (code == 206) h["Content-Range"] = "bytes $start-$end/$size"
        head(code, h, len)
        if (isHead) return
        RandomAccessFile(f, "r").use { raf ->
            raf.seek(start)
            val buf = ByteArray(65536)
            var left = len
            while (left > 0) {
                val n = raf.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                if (n < 0) break
                out.write(buf, 0, n)
                left -= n
            }
        }
    }

    fun flush() {
        out.flush()
    }
}

/** Servidor HTTP/1.1 mínimo, somente em 127.0.0.1, Connection: close, pool limitado. */
class LocalHttpServer(
    private val port: Int,
    private val handler: (HttpReq, Resp) -> Unit
) {
    @Volatile private var ss: ServerSocket? = null
    private val pool = ThreadPoolExecutor(4, 24, 30L, TimeUnit.SECONDS, SynchronousQueue<Runnable>())

    val boundPort: Int get() = ss?.localPort ?: -1
    val running: Boolean get() = ss?.isClosed == false

    fun start() {
        val s = ServerSocket()
        s.reuseAddress = true
        s.bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), port), 50)
        ss = s
        thread(isDaemon = true, name = "openmux-accept") {
            while (!s.isClosed) {
                try {
                    val c = s.accept()
                    try {
                        pool.execute { handle(c) }
                    } catch (e: RejectedExecutionException) {
                        try { c.close() } catch (_: IOException) {}
                    }
                } catch (e: IOException) {
                    if (s.isClosed) break
                }
            }
        }
    }

    fun stop() {
        try { ss?.close() } catch (_: IOException) {}
        pool.shutdownNow()
    }

    private fun readLine(inp: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val c = inp.read()
            if (c < 0) return if (sb.isEmpty()) null else sb.toString()
            if (c == '\n'.code) break
            if (c != '\r'.code) sb.append(c.toChar())
            if (sb.length > 8192) throw IOException("linha longa demais")
        }
        return sb.toString()
    }

    private fun handle(sock: Socket) {
        try {
            sock.soTimeout = 30_000
            sock.tcpNoDelay = true
            val inp = BufferedInputStream(sock.getInputStream(), 8192)
            val out = sock.getOutputStream()
            val line = readLine(inp) ?: return
            val parts = line.split(' ')
            if (parts.size < 3) {
                Resp(out, false).error(400, "requisição inválida"); return
            }
            val method = parts[0].uppercase()
            val target = parts[1]
            val q = target.indexOf('?')
            val path = if (q >= 0) target.substring(0, q) else target
            val query = if (q >= 0) target.substring(q + 1) else null
            val headers = LinkedHashMap<String, String>()
            var n = 0
            while (true) {
                val h = readLine(inp) ?: break
                if (h.isEmpty()) break
                if (++n > 64) {
                    Resp(out, false).error(400, "cabeçalhos demais"); return
                }
                val i = h.indexOf(':')
                if (i > 0) headers[h.substring(0, i).trim().lowercase()] = h.substring(i + 1).trim()
            }
            val len = headers["content-length"]?.toIntOrNull() ?: 0
            if (len > 262_144 || len < 0) {
                Resp(out, false).error(413, "corpo grande demais"); return
            }
            val body = ByteArray(len)
            var read = 0
            while (read < len) {
                val r = inp.read(body, read, len - read)
                if (r < 0) throw IOException("corpo truncado")
                read += r
            }
            val resp = Resp(out, method == "HEAD")
            try {
                handler(HttpReq(method, path, query, headers, body), resp)
            } catch (e: RequestError) {
                if (!resp.sent) resp.error(e.code, e.message ?: "erro")
            } catch (e: IOException) {
                // cliente fechou a conexão (comum com players); nada a fazer
            } catch (e: Throwable) {
                Diag.log("http", "erro interno: ${e.javaClass.simpleName}: ${e.message}")
                if (!resp.sent) resp.error(500, "erro interno")
            }
            try { resp.flush() } catch (_: IOException) {}
        } catch (e: IOException) {
            // timeout / reset
        } finally {
            try { sock.close() } catch (_: IOException) {}
        }
    }
}
