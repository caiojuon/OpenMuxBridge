package org.openmux.bridge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Inicia o serviço após o boot / atualização do app. Limitação do Android: apps que nunca foram
 * abertos (estado "stopped") não recebem BOOT_COMPLETED; por isso a configuração inicial exige
 * abrir o OpenMux Bridge uma vez.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val a = intent?.action ?: return
        if (a == Intent.ACTION_BOOT_COMPLETED || a == "android.intent.action.QUICKBOOT_POWERON" ||
            a == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            if (BridgeConfig.from(context).autoStart) BridgeService.start(context)
        }
    }
}
