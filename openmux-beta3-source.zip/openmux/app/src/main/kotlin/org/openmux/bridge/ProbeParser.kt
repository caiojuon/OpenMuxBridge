package org.openmux.bridge

import org.json.JSONObject

data class StreamInfo(
    val index: Int,
    val type: String,          // video | audio | subtitle | ...
    val typeIndex: Int,        // N em 0:v:N / 0:a:N (conta todos os streams do tipo)
    val codec: String?,
    val lang: String?,
    val channels: Int?,
    val width: Int?,
    val height: Int?,
    val startSec: Double?,
    val bitRate: Long?,
    val attachedPic: Boolean
)

data class ProbeResult(
    val formatName: String?,
    val startSec: Double?,
    val durationSec: Double?,
    val bitRate: Long?,
    val streams: List<StreamInfo>
)

object ProbeParser {
    private fun d(o: JSONObject, k: String): Double? = o.optString(k, "").toDoubleOrNull()
    private fun l(o: JSONObject, k: String): Long? = o.optString(k, "").toLongOrNull()

    fun parse(json: String): ProbeResult {
        val root = JSONObject(json)
        val fmt = root.optJSONObject("format")
        val arr = root.optJSONArray("streams")
        val counters = HashMap<String, Int>()
        val streams = ArrayList<StreamInfo>()
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val s = arr.getJSONObject(i)
                val type = s.optString("codec_type", "unknown")
                val ti = counters[type] ?: 0
                counters[type] = ti + 1
                val tags = s.optJSONObject("tags")
                val disp = s.optJSONObject("disposition")
                streams.add(
                    StreamInfo(
                        index = s.optInt("index", i),
                        type = type,
                        typeIndex = ti,
                        codec = s.optString("codec_name", "").ifEmpty { null },
                        lang = tags?.optString("language", "")?.ifEmpty { null },
                        channels = if (s.has("channels")) s.optInt("channels") else null,
                        width = if (s.has("width")) s.optInt("width") else null,
                        height = if (s.has("height")) s.optInt("height") else null,
                        startSec = d(s, "start_time"),
                        bitRate = l(s, "bit_rate"),
                        attachedPic = (disp?.optInt("attached_pic", 0) ?: 0) == 1
                    )
                )
            }
        }
        return ProbeResult(
            formatName = fmt?.optString("format_name", "")?.ifEmpty { null },
            startSec = fmt?.let { d(it, "start_time") },
            durationSec = fmt?.let { d(it, "duration") },
            bitRate = fmt?.let { l(it, "bit_rate") },
            streams = streams
        )
    }
}
