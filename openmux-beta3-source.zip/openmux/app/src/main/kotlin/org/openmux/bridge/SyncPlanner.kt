package org.openmux.bridge

import kotlin.math.abs

data class SyncPlan(
    /** Atraso aplicado ao áudio (-itsoffset). Positivo = áudio mais tarde. */
    val audioOffsetSec: Double,
    /** Se não nulo, o áudio será reencodado em AAC com atempo (única forma de corrigir diferença de velocidade). */
    val audioTempo: Double?,
    val warnings: List<String>
)

/**
 * Estratégia de sincronização (stream copy):
 *  1. O FFmpeg normaliza cada entrada para começar em t=0 (sem -copyts). Isso resolve fontes
 *     cujos contêineres começam em timestamps diferentes (ex.: MKV em 0.000, TS em 1.400).
 *  2. A diferença de início DENTRO do contêiner (stream vs. contêiner) é preservada.
 *  3. Diferença de CONTEÚDO (logos, cortes) não é detectável sem decodificar: só offsetMs manual.
 *  4. Diferença de VELOCIDADE (25 vs 23,976 fps ≈ 4,27%) não é corrigível com copy: avisa e,
 *     se permitido, reencoda somente o áudio com atempo.
 */
object SyncPlanner {
    fun plan(
        v: ProbeResult,
        vs: StreamInfo,
        a: ProbeResult,
        ast: StreamInfo,
        userOffsetMs: Long,
        expectedDurationSec: Double?,
        allowReencode: Boolean
    ): SyncPlan {
        val w = ArrayList<String>()
        var tempo: Double? = null

        val vc = v.startSec ?: 0.0
        val ac = a.startSec ?: 0.0
        val vst = vs.startSec ?: vc
        val ast0 = ast.startSec ?: ac
        val inherent = (ast0 - ac) - (vst - vc)
        if (abs(inherent) > 0.25) {
            w.add("Os streams começam com diferença de ${Math.round(inherent * 1000)} ms dentro dos contêineres; mantida como está.")
        }

        val vd = v.durationSec
        val ad = a.durationSec
        if (vd != null && ad != null && vd > 0.0 && ad > 0.0) {
            val ratio = ad / vd
            val dev = abs(ratio - 1.0)
            if (dev >= 0.01 && dev <= 0.10) {
                if (allowReencode) {
                    tempo = ad / vd
                    w.add("Durações diferem ${"%.2f".format(dev * 100)}% (provável diferença de fps/velocidade); áudio será reencodado em AAC com atempo=${"%.5f".format(tempo)}.")
                } else {
                    w.add("Durações diferem ${"%.2f".format(dev * 100)}% (provável diferença de fps/velocidade). Com cópia direta o áudio vai derivar; use output.allowAudioReencode=true.")
                }
            } else if (dev > 0.10) {
                w.add("Durações muito diferentes (vídeo ${"%.0f".format(vd)}s, áudio ${"%.0f".format(ad)}s): provavelmente são edições/cortes diferentes.")
            } else if (abs(ad - vd) > 2.0) {
                w.add("Durações diferem ${"%.1f".format(abs(ad - vd))}s; pode haver diferença de cortes. Ajuste offsetMs se houver dessincronia.")
            }
        } else {
            w.add("Duração de uma das fontes é desconhecida; não foi possível checar diferença de velocidade.")
        }

        if (expectedDurationSec != null && vd != null && abs(vd - expectedDurationSec) / expectedDurationSec > 0.05) {
            w.add("A duração do vídeo difere mais de 5% da duração informada pelo plugin.")
        }

        return SyncPlan(userOffsetMs / 1000.0, tempo, w)
    }
}
