package org.openmux.bridge

import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/** Tela única e propositalmente mínima: estado, diagnóstico e liga/desliga. */
class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var btnToggle: Button
    private lateinit var btnPrivate: Button
    private lateinit var btnDiag: Button
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#101418"))
        root.setPadding(64, 40, 64, 40)

        val title = TextView(this)
        title.text = "OpenMux Bridge"
        title.textSize = 30f
        title.setTextColor(Color.WHITE)
        root.addView(title)

        info = TextView(this)
        info.textSize = 18f
        info.setTextColor(Color.parseColor("#CFD8DC"))
        info.setPadding(0, 24, 0, 24)
        val scroll = ScrollView(this)
        scroll.addView(info)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.START
        btnToggle = Button(this)
        btnPrivate = Button(this)
        btnDiag = Button(this)
        for (b in listOf(btnToggle, btnPrivate, btnDiag)) {
            b.isFocusable = true
            row.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = 24 })
        }
        root.addView(row)
        setContentView(root)

        btnToggle.setOnClickListener {
            if (BridgeService.runtime != null) BridgeService.stop(this) else {
                BridgeService.userStopped = false
                BridgeService.start(this)
            }
            handler.postDelayed({ refresh() }, 600)
        }
        btnPrivate.setOnClickListener {
            val cfg = BridgeConfig.from(this)
            cfg.allowPrivateHosts = !cfg.allowPrivateHosts
            refresh()
        }
        btnDiag.setOnClickListener {
            val f = writeDiagFile()
            info.append("\n\nDiagnóstico salvo em:\n" + f.absolutePath)
        }
        btnToggle.requestFocus()

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }
        if (!BridgeService.userStopped) BridgeService.start(this)
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    private fun refresh() {
        val rt = BridgeService.runtime
        val cfg = BridgeConfig.from(this)
        val sb = StringBuilder()
        if (rt != null) {
            sb.append("Serviço: ATIVO\n")
            sb.append("Motor FFmpeg: ").append(if (rt.engine.available()) "OK — " + rt.engine.version() else "AUSENTE (APK sem libffmpeg.so para esta ABI)").append('\n')
            sb.append("Endereço local: http://127.0.0.1:").append(rt.cfg.port).append('\n')
            sb.append("Sessões ativas: ").append(rt.manager.activeCount()).append(" / ").append(rt.cfg.maxSessions).append('\n')
        } else {
            sb.append("Serviço: INATIVO\n")
            sb.append("Motor FFmpeg: ").append(if (FfmpegEngine(this).available()) "presente" else "AUSENTE").append('\n')
            sb.append("Endereço local: http://127.0.0.1:").append(cfg.port).append('\n')
        }
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }
        sb.append("Versão: ").append(ver).append('\n')
        sb.append("ABI do aparelho: ").append(Build.SUPPORTED_ABIS.joinToString(", ")).append('\n')
        sb.append("Fontes em rede local/loopback: ").append(if (cfg.allowPrivateHosts) "PERMITIDAS (modo diagnóstico)" else "bloqueadas").append('\n')
        sb.append("Início automático no boot: ").append(if (cfg.autoStart) "sim" else "não").append('\n')
        sb.append("\nÚltimos eventos:\n")
        for (l in Diag.tail(8)) sb.append(l).append('\n')
        info.text = sb.toString()

        btnToggle.text = if (rt != null) "Parar serviço" else "Iniciar serviço"
        btnPrivate.text = if (cfg.allowPrivateHosts) "Bloquear fontes na rede local" else "Permitir fontes na rede local"
        btnDiag.text = "Salvar diagnóstico"
    }

    private fun writeDiagFile(): File {
        val f = File(filesDir, "openmux-diag.txt")
        val rt = BridgeService.runtime
        val sb = StringBuilder()
        sb.append("OpenMux Bridge diag\n")
        sb.append("device=").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
        sb.append("android=").append(Build.VERSION.RELEASE).append(" api=").append(Build.VERSION.SDK_INT).append('\n')
        sb.append("abis=").append(Build.SUPPORTED_ABIS.joinToString(",")).append('\n')
        sb.append("service=").append(if (rt != null) "ativo" else "inativo").append('\n')
        val eng = rt?.engine ?: FfmpegEngine(this)
        sb.append("engine.available=").append(eng.available()).append('\n')
        sb.append("engine.version=").append(eng.version()).append('\n')
        sb.append("\n--- log ---\n")
        for (l in Diag.tail(300)) sb.append(l).append('\n')
        f.writeText(sb.toString())
        return f
    }
}
