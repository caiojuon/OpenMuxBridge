package org.openmux.bridge

import android.content.Context
import android.content.SharedPreferences

class BridgeConfig(private val prefs: SharedPreferences) {
    companion object {
        fun from(ctx: Context): BridgeConfig =
            BridgeConfig(ctx.getSharedPreferences("openmux", Context.MODE_PRIVATE))
    }

    private fun gi(k: String, d: Int) = prefs.getInt(k, d)
    private fun pi(k: String, v: Int) {
        prefs.edit().putInt(k, v).apply()
    }

    private fun gb(k: String, d: Boolean) = prefs.getBoolean(k, d)
    private fun pb(k: String, v: Boolean) {
        prefs.edit().putBoolean(k, v).apply()
    }

    var port: Int
        get() = gi("port", 8765)
        set(v) = pi("port", v.coerceIn(1024, 65535))

    /** Limite de sessões simultâneas (cada sessão = 1 processo ffmpeg). */
    var maxSessions: Int
        get() = gi("maxSessions", 2)
        set(v) = pi("maxSessions", v.coerceIn(1, 6))

    var idleTimeoutSec: Int
        get() = gi("idleTimeoutSec", 600)
        set(v) = pi("idleTimeoutSec", v.coerceIn(30, 7200))

    var segmentSec: Int
        get() = gi("segmentSec", 4)
        set(v) = pi("segmentSec", v.coerceIn(2, 10))

    var aheadSegments: Int
        get() = gi("aheadSegments", 10)
        set(v) = pi("aheadSegments", v.coerceIn(3, 60))

    var behindSegments: Int
        get() = gi("behindSegments", 8)
        set(v) = pi("behindSegments", v.coerceIn(2, 60))

    /** Teto de armazenamento temporário por sessão (MB). */
    var maxStorageMb: Int
        get() = gi("maxStorageMb", 1536)
        set(v) = pi("maxStorageMb", v.coerceIn(128, 8192))

    var segmentType: String
        get() = prefs.getString("segmentType", "fmp4") ?: "fmp4"
        set(v) {
            prefs.edit().putString("segmentType", if (v == "mpegts") "mpegts" else "fmp4").apply()
        }

    /** Permite fontes em IPs privados/loopback (ex.: Jellyfin na LAN, testes por adb reverse). */
    var allowPrivateHosts: Boolean
        get() = gb("allowPrivateHosts", false)
        set(v) = pb("allowPrivateHosts", v)

    /** Se ligado, /status, /diag, /mux e /session exigem o cabeçalho X-OpenMux-Token. */
    var requireToken: Boolean
        get() = gb("requireToken", false)
        set(v) = pb("requireToken", v)

    /** Requisições com cabeçalho Origin (páginas de navegador) são recusadas por padrão. */
    var allowBrowserOrigins: Boolean
        get() = gb("allowBrowserOrigins", false)
        set(v) = pb("allowBrowserOrigins", v)

    var autoStart: Boolean
        get() = gb("autoStart", true)
        set(v) = pb("autoStart", v)

    val token: String
        get() {
            var t = prefs.getString("token", null)
            if (t == null) {
                t = Ids.newId()
                prefs.edit().putString("token", t).apply()
            }
            return t
        }
}
