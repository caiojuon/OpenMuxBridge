package org.openmux.bridge

import android.content.Context
import java.io.File
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

sealed class CreateResult {
    class Direct(val request: MuxRequest) : CreateResult()
    class Created(val session: Session, val reused: Boolean) : CreateResult()
}

class SessionManager(
    ctx: Context,
    val cfg: BridgeConfig,
    val engine: FfmpegEngine,
    private val portProvider: () -> Int
) {
    private val sessions = ConcurrentHashMap<String, Session>()
    private val root = File(ctx.cacheDir, "sessions")
    private val exec: ExecutorService = Executors.newCachedThreadPool()
    private val janitor: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private val lock = Any()

    init {
        root.deleteRecursively() // sobras de uma execução anterior
        root.mkdirs()
        janitor.scheduleWithFixedDelay({
            try {
                sweep()
            } catch (e: Throwable) {
                Diag.log("janitor", "erro: " + e.message)
            }
        }, 5, 5, TimeUnit.SECONDS)
    }

    fun get(id: String): Session? = sessions[id]
    fun all(): List<Session> = sessions.values.sortedBy { it.createdAt }
    fun activeCount(): Int = sessions.values.count { it.isActive() }

    fun streamUrl(s: Session) = "http://127.0.0.1:${portProvider()}/stream/${s.id}/master.m3u8"

    // ---------------------------------------------------------------- criação

    fun create(raw: MuxRequest): CreateResult {
        val allowPriv = cfg.allowPrivateHosts
        val req = try {
            UrlValidator.validate(raw.video.url, allowPriv)
            raw.audio?.let { UrlValidator.validate(it.url, allowPriv) }
            raw.copy(
                video = SourceSpec(raw.video.url, UrlValidator.sanitizeHeaders(raw.video.headers)),
                audio = raw.audio?.let { SourceSpec(it.url, UrlValidator.sanitizeHeaders(it.headers)) }
            )
        } catch (e: RejectedException) {
            throw RequestError(400, e.message ?: "rejected")
        }

        // Modo DIRECT: nada a combinar -> devolve a URL original, sem ffmpeg.
        if (req.mode == "direct" || req.audio == null || req.audio.url == req.video.url) {
            return CreateResult.Direct(req)
        }
        if (!engine.available()) throw RequestError(503, "motor FFmpeg indisponível neste aparelho")

        val key = Ids.sha256Hex(
            listOf(req.video.url, req.audio.url, req.offsetMs.toString(), req.audioLanguage ?: "", req.contentId ?: "").joinToString("|")
        )
        return synchronized(lock) {
            val existing = sessions.values.firstOrNull { it.key == key && it.isActive() }
            if (existing != null) {
                existing.touch()
                CreateResult.Created(existing, true)
            } else {
                if (activeCount() >= cfg.maxSessions) {
                    // Libera a sessão ociosa mais antiga (sem requisição há >20 s), se houver.
                    val victim = sessions.values
                        .filter { it.isActive() && System.currentTimeMillis() - it.lastAccess.get() > 20_000 }
                        .minByOrNull { it.lastAccess.get() }
                    if (victim == null) throw RequestError(429, "limite de sessões simultâneas atingido (${cfg.maxSessions})")
                    stop(victim.id, "substituída por nova sessão")
                }
                val id = Ids.newId()
                val dir = File(root, id)
                dir.mkdirs()
                val s = Session(id, key, req, dir)
                sessions[id] = s
                exec.execute { runSession(s) }
                Diag.log("session", "criada ${id.take(8)} (vídeo ${Redact.url(req.video.url)}, áudio ${Redact.url(req.audio.url)})")
                CreateResult.Created(s, false)
            }
        }
    }

    // ---------------------------------------------------------------- ciclo de vida

    fun stop(id: String, why: String = "pedido do cliente"): Boolean {
        val s = sessions[id] ?: return false
        if (s.state == SessionState.STOPPED) return true
        s.state = SessionState.STOPPED
        s.endedAt = System.currentTimeMillis()
        s.process?.let { Procs.kill(it) }
        Diag.log("session", "encerrada ${id.take(8)}: $why")
        thread(isDaemon = true) {
            Thread.sleep(300)
            s.dir.deleteRecursively()
        }
        return true
    }

    fun stopAll() {
        sessions.keys.toList().forEach { stop(it, "serviço parando") }
        janitor.shutdownNow()
        exec.shutdownNow()
        root.deleteRecursively()
    }

    /** Muda o offset do áudio. Reinicia a sessão (o cliente deve recarregar o manifesto). */
    fun setOffset(id: String, offsetMs: Long): Session {
        val s = sessions[id] ?: throw RequestError(404, "sessão não encontrada")
        if (!s.isActive()) throw RequestError(409, "sessão encerrada")
        if (offsetMs < -600000L || offsetMs > 600000L) throw RequestError(400, "offsetMs fora do intervalo")
        s.restartRequested = true
        s.process?.let { Procs.kill(it) }
        s.request = s.request.copy(offsetMs = offsetMs)
        s.touch()
        exec.execute {
            // Aguarda a thread anterior soltar a sessão.
            var tries = 0
            while (s.restartRequested && tries++ < 100) Thread.sleep(100)
            s.dir.listFiles()?.forEach { it.delete() }
            s.maxRequestedSeg.set(-1)
            s.segmentsGenerated = 0
            s.paused = false
            s.error = null
            s.state = SessionState.CREATED
            runSession(s)
        }
        return s
    }

    private fun sweep() {
        val now = System.currentTimeMillis()
        for (s in sessions.values.toList()) {
            if (s.isActive()) {
                if (now - s.lastAccess.get() > cfg.idleTimeoutSec * 1000L) stop(s.id, "ociosa")
            } else if (s.endedAt > 0 && now - s.endedAt > 60_000) {
                sessions.remove(s.id)
                s.dir.deleteRecursively()
            }
        }
    }

    // ---------------------------------------------------------------- pipeline de uma sessão

    private fun runSession(s: Session) {
        try {
            val req = s.request
            val audioSpec = req.audio ?: throw IllegalStateException("sem áudio")
            val base = "http://127.0.0.1:${portProvider()}/_src/${s.id}"
            if (s.videoProbe == null || s.audioProbe == null) {
                s.state = SessionState.PROBING
                val fv = exec.submit(Callable { engine.probe("$base/v") })
                val fa = exec.submit(Callable { engine.probe("$base/a") })
                s.videoProbe = try { fv.get(70, TimeUnit.SECONDS) } catch (e: Exception) { throw IllegalStateException("fonte de vídeo: " + (e.cause?.message ?: e.message)) }
                s.audioProbe = try { fa.get(70, TimeUnit.SECONDS) } catch (e: Exception) { throw IllegalStateException("fonte de áudio: " + (e.cause?.message ?: e.message)) }
            }
            if (s.state == SessionState.STOPPED) return
            val vp = s.videoProbe!!
            val ap = s.audioProbe!!

            val vs = pickVideo(vp, req.output.videoStream) ?: throw IllegalStateException("nenhum stream de vídeo na fonte de vídeo")
            val warns = ArrayList<String>()
            val ast = pickAudio(ap, req.audioLanguage, req.output.audioStream, warns) ?: throw IllegalStateException("nenhum stream de áudio na fonte de áudio")
            val plan = SyncPlanner.plan(vp, vs, ap, ast, req.offsetMs, req.durationSec, req.output.allowAudioReencode)
            s.warnings.clear()
            s.warnings.addAll(warns)
            s.warnings.addAll(plan.warnings)
            s.audioTempo = plan.audioTempo

            val segType = (req.output.segmentType ?: cfg.segmentType).let { if (it == "mpegts") "mpegts" else "fmp4" }
            val segSec = (req.output.segmentSec ?: cfg.segmentSec).coerceIn(2, 10)
            s.segmentType = segType

            val muxPlan = MuxPlan(
                videoInput = "$base/v", audioInput = "$base/a",
                videoTypeIndex = vs.typeIndex, audioTypeIndex = ast.typeIndex,
                audioOffsetSec = plan.audioOffsetSec, audioTempo = plan.audioTempo,
                audioLang = req.audioLanguage ?: ast.lang,
                segmentType = segType, segmentSec = segSec, outDir = s.dir.absolutePath
            )
            s.state = SessionState.STARTING
            launchAndMonitor(s, muxPlan, vs, ast)
        } catch (e: Throwable) {
            if (s.state != SessionState.STOPPED) {
                s.error = Redact.text(e.message ?: e.javaClass.simpleName)
                s.state = SessionState.FAILED
                s.endedAt = System.currentTimeMillis()
                Diag.log("session", "falhou ${s.id.take(8)}: ${s.error}")
            }
        } finally {
            s.restartRequested = false
        }
    }

    private fun pickVideo(p: ProbeResult, wanted: Int?): StreamInfo? {
        val vids = p.streams.filter { it.type == "video" }
        if (wanted != null) return vids.firstOrNull { it.typeIndex == wanted }
        return vids.firstOrNull { !it.attachedPic }
    }

    private fun pickAudio(p: ProbeResult, lang: String?, wanted: Int?, warns: MutableList<String>): StreamInfo? {
        val auds = p.streams.filter { it.type == "audio" }
        if (wanted != null) return auds.firstOrNull { it.typeIndex == wanted }
        if (lang != null) {
            val m = auds.firstOrNull { CommandBuilder.langMatches(it.lang, lang) }
            if (m != null) return m
            if (auds.isNotEmpty()) warns.add("Idioma de áudio '$lang' não encontrado na fonte; usando o primeiro stream de áudio.")
        }
        return auds.firstOrNull()
    }

    private fun launchAndMonitor(s: Session, plan: MuxPlan, vs: StreamInfo, ast: StreamInfo) {
        val cmd = listOf(engine.ffmpeg.path) + CommandBuilder.muxArgs(plan)
        val pb = ProcessBuilder(cmd)
        pb.directory(s.dir)
        pb.redirectOutput(ProcessBuilder.Redirect.to(File("/dev/null")))
        val p = pb.start()
        p.outputStream.close()
        s.process = p
        thread(isDaemon = true, name = "ffmpeg-log-${s.id.take(6)}") {
            try {
                p.errorStream.bufferedReader().forEachLine { s.addLog(Redact.text(it)) }
            } catch (_: Exception) {
            }
        }
        val started = System.currentTimeMillis()
        var lastSize = 0L
        var lastSizeAt = 0L
        val fmp4 = plan.segmentType != "mpegts"

        while (true) {
            if (s.state == SessionState.STOPPED || s.restartRequested) {
                Procs.kill(p)
                return
            }
            val exit = Procs.exitCode(p)
            val segs = listSegments(s.dir)
            s.segmentsGenerated = segs.size

            if (s.state == SessionState.STARTING && segs.isNotEmpty() &&
                File(s.dir, "index.m3u8").exists() && (!fmp4 || File(s.dir, "init.mp4").exists())
            ) {
                writeMaster(s, vs, ast)
                s.state = SessionState.READY
                Diag.log("session", "pronta ${s.id.take(8)} (primeiro segmento em ${(System.currentTimeMillis() - started)} ms)")
            }

            if (exit != null) {
                if (exit == 0 && segs.isNotEmpty()) {
                    if (s.state == SessionState.STARTING) {
                        writeMaster(s, vs, ast)
                    }
                    s.state = SessionState.ENDED
                    Diag.log("session", "ffmpeg concluiu ${s.id.take(8)} (${segs.size} segmentos)")
                } else {
                    s.error = "ffmpeg encerrou com código $exit: " + s.logLines().takeLast(3).joinToString(" | ")
                    s.state = SessionState.FAILED
                    s.endedAt = System.currentTimeMillis()
                    Diag.log("session", "ffmpeg falhou ${s.id.take(8)}: ${s.error}")
                }
                return
            }

            val now = System.currentTimeMillis()
            if (now - lastSizeAt > 2000) {
                s.dirBytes = dirSize(s.dir)
                lastSizeAt = now
                lastSize = s.dirBytes
            }
            backpressure(s, p, segs)
            trim(s, segs)

            if (s.state == SessionState.STARTING && now - started > 90_000) {
                s.error = "tempo esgotado aguardando o primeiro segmento"
                s.state = SessionState.FAILED
                s.endedAt = now
                Procs.kill(p)
                return
            }
            Thread.sleep(400)
        }
    }

    private fun backpressure(s: Session, p: Process, segs: List<Int>) {
        val requested = maxOf(s.maxRequestedSeg.get(), 0)
        val last = segs.maxOrNull() ?: -1
        val ahead = last - requested
        val over = s.dirBytes > cfg.maxStorageMb * 1024L * 1024L
        if (!s.paused && (ahead >= cfg.aheadSegments || over)) {
            if (Procs.signal(p, 19)) s.paused = true // SIGSTOP
        } else if (s.paused && ahead < cfg.aheadSegments - 2 && !over) {
            if (Procs.signal(p, 18)) s.paused = false // SIGCONT
        }
    }

    private fun trim(s: Session, segs: List<Int>) {
        val requested = s.maxRequestedSeg.get()
        if (requested < 0) return
        val ext = if (s.segmentType == "mpegts") "ts" else "m4s"
        val limit = requested - cfg.behindSegments
        for (i in segs) {
            if (i < limit) File(s.dir, String.format(java.util.Locale.US, "seg%05d.%s", i, ext)).delete()
        }
    }

    private fun listSegments(dir: File): List<Int> {
        val names = dir.list() ?: return emptyList()
        val out = ArrayList<Int>()
        for (n in names) {
            val i = HlsUtil.segmentIndex(n)
            if (i != null) out.add(i)
        }
        out.sort()
        return out
    }

    private fun dirSize(dir: File): Long {
        var t = 0L
        dir.listFiles()?.forEach { t += it.length() }
        return t
    }

    private fun writeMaster(s: Session, vs: StreamInfo, ast: StreamInfo) {
        val vbr = vs.bitRate ?: s.videoProbe?.bitRate ?: 8_000_000L
        val abr = ast.bitRate ?: 192_000L
        val res = if (vs.width != null && vs.height != null) ",RESOLUTION=${vs.width}x${vs.height}" else ""
        val sb = StringBuilder()
        sb.append("#EXTM3U\n#EXT-X-VERSION:7\n#EXT-X-START:TIME-OFFSET=0.0,PRECISE=YES\n#EXT-X-INDEPENDENT-SEGMENTS\n")
        sb.append("#EXT-X-STREAM-INF:BANDWIDTH=").append(vbr + abr).append(res).append("\nindex.m3u8\n")
        val tmp = File(s.dir, "master.m3u8.tmp")
        tmp.writeText(sb.toString())
        tmp.renameTo(File(s.dir, "master.m3u8"))
    }
}
