package org.openmux.bridge

import java.util.Locale

data class MuxPlan(
    val videoInput: String,
    val audioInput: String,
    val videoTypeIndex: Int,
    val audioTypeIndex: Int,
    val audioOffsetSec: Double,
    val audioTempo: Double?,
    val audioLang: String?,
    val segmentType: String,   // fmp4 | mpegts
    val segmentSec: Int,
    val outDir: String
)

object CommandBuilder {
    private val LANGS = mapOf(
        "pt" to "por", "pb" to "por", "pob" to "por", "por" to "por",
        "en" to "eng", "eng" to "eng", "es" to "spa", "spa" to "spa",
        "fr" to "fra", "fre" to "fra", "fra" to "fra", "de" to "deu", "ger" to "deu", "deu" to "deu",
        "it" to "ita", "ita" to "ita", "ja" to "jpn", "jpn" to "jpn", "ko" to "kor", "kor" to "kor",
        "zh" to "zho", "chi" to "zho", "zho" to "zho", "ru" to "rus", "rus" to "rus", "hi" to "hin", "hin" to "hin"
    )

    /** "pt-BR" -> "por"; desconhecido de 3 letras passa direto; senão null. */
    fun lang3(raw: String?): String? {
        if (raw == null) return null
        val base = raw.trim().lowercase().split('-', '_').firstOrNull() ?: return null
        if (base.isEmpty()) return null
        return LANGS[base] ?: if (base.length == 3 && base.all { it in 'a'..'z' }) base else null
    }

    fun langMatches(streamLang: String?, wanted: String?): Boolean {
        val a = lang3(streamLang)
        val b = lang3(wanted)
        return a != null && b != null && a == b
    }

    private fun fmt(x: Double): String = String.format(Locale.US, "%.3f", x)

    private fun inputOpts(a: MutableList<String>) {
        a.addAll(listOf("-fflags", "+genpts+discardcorrupt", "-thread_queue_size", "512"))
        // Segunda camada de reconexão (a primeira é do proxy interno do Bridge).
        a.addAll(listOf("-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", "4", "-rw_timeout", "30000000"))
    }

    fun muxArgs(p: MuxPlan): List<String> {
        val a = ArrayList<String>()
        a.addAll(listOf("-y", "-hide_banner", "-nostdin", "-nostats", "-loglevel", "warning"))

        inputOpts(a)
        a.addAll(listOf("-i", p.videoInput))

        inputOpts(a)
        if (p.audioOffsetSec != 0.0) a.addAll(listOf("-itsoffset", fmt(p.audioOffsetSec)))
        a.addAll(listOf("-i", p.audioInput))

        a.addAll(listOf("-map", "0:v:${p.videoTypeIndex}", "-map", "1:a:${p.audioTypeIndex}"))
        a.addAll(listOf("-map_metadata", "-1", "-map_chapters", "-1", "-sn", "-dn"))
        a.addAll(listOf("-c:v", "copy"))
        if (p.audioTempo != null) {
            a.addAll(listOf("-filter:a", "atempo=" + String.format(Locale.US, "%.6f", p.audioTempo), "-c:a", "aac", "-b:a", "256k"))
        } else {
            a.addAll(listOf("-c:a", "copy"))
        }
        val l3 = lang3(p.audioLang)
        if (l3 != null) a.addAll(listOf("-metadata:s:a:0", "language=$l3"))

        a.addAll(listOf("-shortest", "-avoid_negative_ts", "make_zero", "-max_interleave_delta", "0"))

        val fmp4 = p.segmentType != "mpegts"
        val ext = if (fmp4) "m4s" else "ts"
        a.addAll(
            listOf(
                "-f", "hls",
                "-hls_time", p.segmentSec.toString(),
                "-hls_list_size", "0",
                "-hls_playlist_type", "event",
                "-hls_flags", "independent_segments+temp_file",
                "-start_number", "0"
            )
        )
        if (fmp4) {
            a.addAll(listOf("-hls_segment_type", "fmp4", "-hls_fmp4_init_filename", "init.mp4"))
        } else {
            a.addAll(listOf("-hls_segment_type", "mpegts"))
        }
        a.addAll(listOf("-hls_segment_filename", p.outDir + "/seg%05d." + ext, p.outDir + "/index.m3u8"))
        return a
    }

    fun probeArgs(url: String): List<String> = listOf(
        "-v", "error", "-print_format", "json", "-show_format", "-show_streams",
        "-probesize", "10000000", "-analyzeduration", "10000000",
        "-rw_timeout", "20000000", url
    )
}
