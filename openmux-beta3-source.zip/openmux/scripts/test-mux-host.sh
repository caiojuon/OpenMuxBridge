#!/usr/bin/env bash
# Valida NO HOST (x86, ffmpeg do sistema) a mesma linha de comando que o Bridge monta
# em CommandBuilder.muxArgs(): duas fontes HTTP independentes, copy-mux, HLS, sincronização.
# NÃO prova nada sobre o binário ARM nem sobre o Android; prova a lógica dos argumentos.
#
# Uso: scripts/test-mux-host.sh [workdir]
set -euo pipefail

WORK="${1:-$(mktemp -d)}"
HERE="$(cd "$(dirname "$0")/.." && pwd)"
FF="${FFMPEG:-ffmpeg}"
FP="${FFPROBE:-ffprobe}"
PORT=9100
mkdir -p "$WORK"
cd "$WORK"
pass=0; fail=0
ok()  { echo "  PASS: $*"; pass=$((pass+1)); }
bad() { echo "  FAIL: $*"; fail=$((fail+1)); }

echo "== gerando fontes de teste"
# Fonte A: vídeo H.264 (aqui 'o 4K'), áudio inglês (será descartado). 20 s.
$FF -v error -y -f lavfi -i testsrc=size=640x360:rate=24:duration=20 \
    -f lavfi -i "sine=frequency=440:duration=20" -c:v libx264 -g 48 -pix_fmt yuv420p -c:a aac src_video.mkv
# Fonte B: só o áudio (AC3), com 0,5 s de silêncio inicial no CONTEÚDO (dublagem com offset).
$FF -v error -y -f lavfi -i "sine=frequency=880:duration=20" -af adelay=500:all=1 -c:a ac3 -b:a 192k src_audio.mkv

python3 "$HERE/tests/range_server.py" "$WORK" $PORT "https://provider.example/" &
SRV=$!
trap 'kill $SRV 2>/dev/null || true' EXIT
sleep 1
V="http://127.0.0.1:$PORT/src_video.mkv"
A="http://127.0.0.1:$PORT/src_audio.mkv"
HDR=$'Referer: https://provider.example/\r\n'

echo "== provedor exige Referer"
code=$(curl -s -o /dev/null -w '%{http_code}' "$V"); [ "$code" = 403 ] && ok "sem Referer -> 403" || bad "esperado 403, veio $code"
code=$(curl -s -o /dev/null -w '%{http_code}' -H 'Referer: https://provider.example/' -H 'Range: bytes=0-9' "$V"); [ "$code" = 206 ] && ok "com Referer + Range -> 206" || bad "esperado 206, veio $code"

IN_OPTS=(-fflags +genpts+discardcorrupt -thread_queue_size 512 -reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 4 -rw_timeout 30000000 -headers "$HDR")

run_case() {
  local type="$1" off="$2" outdir="out_$1_$2" ext
  rm -rf "$outdir"; mkdir -p "$outdir"
  [ "$type" = mpegts ] && ext=ts || ext=m4s
  local segopts=(-hls_segment_type "$type")
  [ "$type" = fmp4 ] && segopts+=(-hls_fmp4_init_filename init.mp4)
  local offopts=()
  [ "$off" != "0.000" ] && offopts=(-itsoffset "$off")
  echo "== caso: segmentos=$type itsoffset=$off"
  $FF -y -hide_banner -nostdin -nostats -loglevel warning \
    "${IN_OPTS[@]}" -i "$V" \
    "${IN_OPTS[@]}" "${offopts[@]}" -i "$A" \
    -map 0:v:0 -map 1:a:0 -map_metadata -1 -map_chapters -1 -sn -dn \
    -c:v copy -c:a copy -metadata:s:a:0 language=por \
    -shortest -avoid_negative_ts make_zero -max_interleave_delta 0 \
    -f hls -hls_time 4 -hls_list_size 0 -hls_playlist_type event \
    -hls_flags independent_segments+temp_file -start_number 0 \
    "${segopts[@]}" -hls_segment_filename "$outdir/seg%05d.$ext" "$outdir/index.m3u8" 2> "$outdir/ffmpeg.log" \
    && ok "ffmpeg terminou com código 0" || { bad "ffmpeg falhou"; cat "$outdir/ffmpeg.log"; return; }

  n=$(ls "$outdir"/seg*.$ext 2>/dev/null | wc -l)
  [ "$n" -ge 4 ] && ok "$n segmentos gerados" || bad "poucos segmentos ($n)"
  ls "$outdir" | grep -q '\.tmp$' && bad "sobrou arquivo .tmp" || ok "sem .tmp restante"
  grep -q '#EXT-X-ENDLIST' "$outdir/index.m3u8" && ok "playlist finalizada (ENDLIST)" || bad "sem ENDLIST"
  [ "$type" = fmp4 ] && { [ -f "$outdir/init.mp4" ] && ok "init.mp4 presente" || bad "init.mp4 ausente"; }

  streams=$($FP -v error -show_entries stream=codec_type,codec_name -of csv=p=0 "$outdir/index.m3u8" | tr -d ',' | sort -u | tr '\n' ' ')
  echo "$streams" | grep -q 'h264video' && echo "$streams" | grep -q 'ac3audio' \
    && ok "saída = vídeo h264 (fonte A) + áudio ac3 (fonte B): $streams" || bad "streams inesperados: $streams"

  lang=$($FP -v error -select_streams a:0 -show_entries stream_tags=language -of default=nw=1:nk=1 "$outdir/index.m3u8" | head -1)
  # (em fmp4 o metadado de idioma costuma sobreviver; em mpegts também via descritor)
  [ "$lang" = por ] && ok "idioma do áudio marcado como por" || echo "  INFO: idioma lido='$lang' (não é falha da lógica de sync)"

  # Sincronização: diferença entre start_time de áudio e vídeo na saída.
  vs=$($FP -v error -select_streams v:0 -show_entries stream=start_time -of default=nw=1:nk=1 "$outdir/index.m3u8" | head -1)
  as=$($FP -v error -select_streams a:0 -show_entries stream=start_time -of default=nw=1:nk=1 "$outdir/index.m3u8" | head -1)
  python3 - "$vs" "$as" "$off" <<'PY'
import sys
v, a, off = float(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3])
d = v - a
print(f"  INFO: start vídeo={v:.3f}s áudio={a:.3f}s  (vídeo - áudio = {d:+.3f}s)  itsoffset aplicado ao áudio={off:+.3f}s")
sys.exit(0)
PY
  echo "$vs $as" > "$outdir/starts.txt"
}

run_case fmp4 0.000
run_case fmp4 -0.500
run_case mpegts -0.500

echo "== backpressure: SIGSTOP/SIGCONT não pode corromper a saída"
outdir=out_signal; rm -rf "$outdir"; mkdir -p "$outdir"
# fonte maior para dar tempo de pausar
$FF -v error -y -f lavfi -i testsrc=size=640x360:rate=24:duration=120 -c:v libx264 -g 48 -pix_fmt yuv420p -b:v 6M long_video.mkv
$FF -v error -y -f lavfi -i "sine=frequency=880:duration=120" -c:a ac3 long_audio.mkv
$FF -y -hide_banner -nostdin -nostats -loglevel warning \
  -readrate 20 -headers "$HDR" -i "http://127.0.0.1:$PORT/long_video.mkv" -readrate 20 -headers "$HDR" -i "http://127.0.0.1:$PORT/long_audio.mkv" \
  -map 0:v:0 -map 1:a:0 -c copy -shortest -f hls -hls_time 4 -hls_list_size 0 -hls_playlist_type event \
  -hls_flags independent_segments+temp_file -hls_segment_type fmp4 -hls_fmp4_init_filename init.mp4 \
  -hls_segment_filename "$outdir/seg%05d.m4s" "$outdir/index.m3u8" 2> "$outdir/ffmpeg.log" &
FP_PID=$!
sleep 1
kill -STOP $FP_PID; sleep 1.5
n1=$(ls "$outdir"/seg*.m4s 2>/dev/null | wc -l); sleep 1.5; n2=$(ls "$outdir"/seg*.m4s 2>/dev/null | wc -l)
[ "$n1" = "$n2" ] && ok "pausado: nenhum segmento novo durante SIGSTOP ($n1)" || bad "gerou segmentos pausado ($n1 -> $n2)"
kill -CONT $FP_PID
wait $FP_PID && ok "retomou com SIGCONT e terminou com código 0" || bad "falhou após SIGCONT"
total=$(ls "$outdir"/seg*.m4s | wc -l)
dur=$($FP -v error -show_entries format=duration -of csv=p=0 "$outdir/index.m3u8")
echo "  INFO: $total segmentos, duração HLS=${dur}s (esperado ~120s)"
python3 -c "import sys; d=float('$dur'); sys.exit(0 if 117<=d<=121 else 1)" && ok "duração total íntegra após pause/resume" || bad "duração fora do esperado"

echo
echo "RESULTADO: $pass passaram, $fail falharam"
[ "$fail" = 0 ]
