#!/usr/bin/env bash
# Compila FFmpeg + FFprobe (LGPL, estáticos, sem GPL/nonfree) para Android via NDK e instala
# como executáveis "disfarçados" de lib*.so em app/src/main/jniLibs/<abi>/.
#
# Uso:   ANDROID_NDK_HOME=/caminho/ndk scripts/build-ffmpeg.sh [abi]      (padrão: armeabi-v7a)
# ABIs:  armeabi-v7a | arm64-v8a
#
# STATUS: escrito e revisado, mas AINDA NÃO EXECUTADO (o ambiente de desenvolvimento não tinha
# NDK nem acesso a dl.google.com). A primeira execução real acontece no GitHub Actions.
set -euo pipefail

ABI="${1:-armeabi-v7a}"
FFMPEG_TAG="${FFMPEG_TAG:-n7.1.1}"
API="${ANDROID_API:-24}"
: "${ANDROID_NDK_HOME:?defina ANDROID_NDK_HOME (NDK r26+; testado em r27)}"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="${BUILD_DIR:-$ROOT/build/ffmpeg-$ABI}"
OUT="$ROOT/app/src/main/jniLibs/$ABI"
TOOLCHAIN="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64"
[ -d "$TOOLCHAIN" ] || { echo "toolchain não encontrada em $TOOLCHAIN"; exit 1; }

case "$ABI" in
  armeabi-v7a)
    TRIPLE=armv7a-linux-androideabi; FF_ARCH=arm; FF_CPU=armv7-a
    EXTRA_CFLAGS="-march=armv7-a -mfpu=neon -mfloat-abi=softfp" ;;
  arm64-v8a)
    TRIPLE=aarch64-linux-android; FF_ARCH=aarch64; FF_CPU=armv8-a
    EXTRA_CFLAGS="-march=armv8-a" ;;
  *) echo "ABI não suportada: $ABI"; exit 1 ;;
esac

CC="$TOOLCHAIN/bin/${TRIPLE}${API}-clang"
CXX="$TOOLCHAIN/bin/${TRIPLE}${API}-clang++"
[ -x "$CC" ] || { echo "compilador não encontrado: $CC"; exit 1; }

mkdir -p "$BUILD"
cd "$BUILD"
if [ ! -d FFmpeg ]; then
  # Repositório oficial: https://github.com/FFmpeg/FFmpeg
  git clone --depth 1 --branch "$FFMPEG_TAG" https://github.com/FFmpeg/FFmpeg.git
fi
cd FFmpeg
make distclean >/dev/null 2>&1 || true

# Só o necessário: HTTP em texto puro (o Bridge cuida de TLS), demux de contêineres comuns,
# cópia de streams, mux HLS (fMP4 / MPEG-TS) e o mínimo para o caminho opcional de reencode
# de áudio (decoders AAC/AC3/E-AC3 + encoder AAC + atempo).
./configure \
  --prefix="$BUILD/install" \
  --enable-cross-compile --target-os=android --arch="$FF_ARCH" --cpu="$FF_CPU" \
  --cc="$CC" --cxx="$CXX" \
  --ar="$TOOLCHAIN/bin/llvm-ar" --nm="$TOOLCHAIN/bin/llvm-nm" \
  --ranlib="$TOOLCHAIN/bin/llvm-ranlib" --strip="$TOOLCHAIN/bin/llvm-strip" \
  --extra-cflags="-O2 -fPIC -fPIE $EXTRA_CFLAGS" \
  --extra-ldflags="-pie" \
  --disable-everything --disable-autodetect --disable-doc --disable-debug \
  --disable-ffplay --disable-avdevice --disable-postproc \
  --enable-ffmpeg --enable-ffprobe --enable-static --disable-shared \
  --enable-network \
  --enable-protocol=file,http,tcp,pipe \
  --enable-demuxer=matroska,mov,mpegts,aac,ac3,eac3,mp3,flac,ogg,dts,truehd \
  --enable-muxer=hls,mp4,mpegts \
  --enable-parser=h264,hevc,av1,vp9,mpeg4video,aac,aac_latm,ac3,opus,vorbis,mpegaudio,flac,dca \
  --enable-bsf=aac_adtstoasc,h264_mp4toannexb,hevc_mp4toannexb,extract_extradata,null \
  --enable-decoder=aac,ac3,eac3 \
  --enable-encoder=aac \
  --enable-filter=anull,aformat,aresample,atempo,abuffer,abuffersink,buffer,buffersink,null,format \
  --enable-pic

make -j"$(nproc)"

mkdir -p "$OUT"
"$TOOLCHAIN/bin/llvm-strip" -o "$OUT/libffmpeg.so"  ffmpeg
"$TOOLCHAIN/bin/llvm-strip" -o "$OUT/libffprobe.so" ffprobe
chmod 755 "$OUT/libffmpeg.so" "$OUT/libffprobe.so"

echo "== verificação dos binários gerados"
for f in libffmpeg.so libffprobe.so; do
  echo "-- $f"
  "$TOOLCHAIN/bin/llvm-readelf" -h "$OUT/$f" | grep -E "Class|Machine|Type"
  echo "   NEEDED:"; "$TOOLCHAIN/bin/llvm-readelf" -d "$OUT/$f" | grep NEEDED || true
  "$TOOLCHAIN/bin/llvm-readelf" -l "$OUT/$f" | grep -i interpreter || echo "   (sem interpretador!)"
done
# Falha se a máquina não for a esperada (evita empacotar binário da arquitetura errada).
case "$ABI" in
  armeabi-v7a) "$TOOLCHAIN/bin/llvm-readelf" -h "$OUT/libffmpeg.so" | grep -q "Machine:.*ARM$" ;;
  arm64-v8a)   "$TOOLCHAIN/bin/llvm-readelf" -h "$OUT/libffmpeg.so" | grep -q "AArch64" ;;
esac
"$TOOLCHAIN/bin/llvm-readelf" -h "$OUT/libffmpeg.so" | grep -q "Type:.*DYN" # PIE (exigido pelo Android)

# Registro reprodutível do que foi compilado.
{
  echo "FFmpeg tag: $FFMPEG_TAG"
  echo "ABI: $ABI  API: $API  NDK: $(basename "$ANDROID_NDK_HOME")"
  echo "Licença efetiva: LGPL v2.1+ (sem --enable-gpl / --enable-nonfree)"
  echo "Configure:"; grep -m1 '^configuration:' config.h 2>/dev/null || ./ffmpeg -hide_banner -version 2>/dev/null | grep configuration || true
} > "$OUT/FFMPEG_BUILD_INFO.txt"
echo "OK -> $OUT"
