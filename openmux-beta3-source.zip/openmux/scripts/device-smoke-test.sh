#!/usr/bin/env bash
# Teste de fumaça NO APARELHO (TCL C6K) via adb, a partir de um PC (ou do GitHub Codespaces
# conectado por adb). Cobre os itens 1-9 da Etapa 4. Ainda NÃO foi executado por ninguém.
#
# Pré-requisitos: adb conectado à TV (Opções do desenvolvedor > Depuração USB/de rede),
#                 ffmpeg/ffprobe/curl/python3 no PC.
# Uso: scripts/device-smoke-test.sh OpenMuxBridge-Beta2-armv7a.apk
set -euo pipefail
APK="${1:?informe o caminho do APK}"
HERE="$(cd "$(dirname "$0")/.." && pwd)"
WORK="$(mktemp -d)"
PORT=8765; SRC_PORT=9000
step() { echo; echo "### $*"; }

step "1. Instalação (ABI do aparelho: $(adb shell getprop ro.product.cpu.abilist | tr -d '\r'))"
adb install -r "$APK"

step "2. Inicialização do serviço"
adb shell am start -n org.openmux.bridge/.MainActivity >/dev/null
sleep 4
adb forward tcp:$PORT tcp:$PORT >/dev/null

step "3. /health"
curl -fsS "http://127.0.0.1:$PORT/health"; echo
curl -fsS "http://127.0.0.1:$PORT/status" | python3 -m json.tool | head -30

step "4-5. Duas fontes independentes (servidas do PC por adb reverse)"
cd "$WORK"
ffmpeg -v error -y -f lavfi -i testsrc=size=1280x720:rate=24:duration=60 -c:v libx264 -g 48 -pix_fmt yuv420p src_video.mkv
ffmpeg -v error -y -f lavfi -i "sine=frequency=880:duration=60" -af adelay=500:all=1 -c:a ac3 -b:a 192k src_audio.mkv
python3 "$HERE/tests/range_server.py" "$WORK" $SRC_PORT "https://provider.example/" &
SRV=$!; trap 'kill $SRV 2>/dev/null || true' EXIT
adb reverse tcp:$SRC_PORT tcp:$SRC_PORT >/dev/null
echo ">> No app: botão 'Permitir fontes na rede local' (fontes em 127.0.0.1 são bloqueadas por padrão). Pressione Enter após ativar."
read -r _
RESP=$(curl -fsS -X POST "http://127.0.0.1:$PORT/mux" -H 'Content-Type: application/json' -d "{
  \"videoUrl\":\"http://127.0.0.1:$SRC_PORT/src_video.mkv\",\"videoHeaders\":{\"Referer\":\"https://provider.example/\"},
  \"audioUrl\":\"http://127.0.0.1:$SRC_PORT/src_audio.mkv\",\"audioHeaders\":{\"Referer\":\"https://provider.example/\"},
  \"audioLanguage\":\"pt-BR\",\"contentId\":\"smoke:1\",\"offsetMs\":-500}")
echo "$RESP" | python3 -m json.tool
ID=$(echo "$RESP" | python3 -c 'import sys,json; print(json.load(sys.stdin)["id"])')

step "6-7. Sincronização e HLS (manifesto aguarda a sessão ficar pronta)"
curl -fsS "http://127.0.0.1:$PORT/stream/$ID/master.m3u8" | tee master.m3u8
curl -fsS "http://127.0.0.1:$PORT/stream/$ID/index.m3u8" | tee index.m3u8 | head -20
ffprobe -v error -show_entries stream=codec_type,codec_name,start_time -of csv=p=0 "http://127.0.0.1:$PORT/stream/$ID/master.m3u8"

step "8. Reprodução (decodifica 10 s pela URL HLS; reproduza também no Nuvio/VLC/Just Player manualmente)"
ffmpeg -v error -t 10 -i "http://127.0.0.1:$PORT/stream/$ID/master.m3u8" -f null - && echo "decodificou OK"

step "10. CPU / memória do ffmpeg e do serviço"
adb shell "top -b -n 1 | grep -E 'ffmpeg|openmux' || true"
adb shell dumpsys meminfo org.openmux.bridge | sed -n 1,12p
curl -fsS "http://127.0.0.1:$PORT/session/$ID" | python3 -m json.tool

step "9. Encerramento"
curl -fsS -X DELETE "http://127.0.0.1:$PORT/session/$ID"; echo
sleep 1
curl -s -o /dev/null -w "GET /session após DELETE: HTTP %{http_code}\n" "http://127.0.0.1:$PORT/session/$ID"
echo "Reinicie o app (am force-stop) e verifique que o serviço volta: adb shell am force-stop org.openmux.bridge; adb shell am broadcast -a android.intent.action.BOOT_COMPLETED -p org.openmux.bridge"
