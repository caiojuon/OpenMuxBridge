// PLUGIN DE TESTE — não é o OpenMux Plugin final.
// Objetivo: descobrir se um scraper local do Nuvio consegue chamar http://127.0.0.1:8765 no SEU
// aparelho. Sem async/await (o sandbox do Nuvio só aceita Promises). O formato exato do objeto de
// stream NÃO foi verificado contra a documentação oficial do Nuvio; ajuste se necessário.
function getStreams(tmdbId, mediaType, season, episode) {
  return fetch('http://127.0.0.1:8765/health')
    .then(function (r) { return r.json(); })
    .then(function (j) {
      return [{
        name: 'OpenMux probe',
        title: 'OK: Bridge alcançável (v' + j.version + ')',
        url: 'http://127.0.0.1:8765/health',
        quality: 'probe'
      }];
    })
    .catch(function (e) {
      return [{
        name: 'OpenMux probe',
        title: 'FALHOU: ' + String(e && e.message ? e.message : e),
        url: 'http://invalid.local/',
        quality: 'probe'
      }];
    });
}
module.exports = { getStreams };
